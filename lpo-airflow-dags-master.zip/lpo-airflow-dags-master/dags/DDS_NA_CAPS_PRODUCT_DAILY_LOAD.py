#========================================================================================================
# Script Name : DDS_NA_CAPS_PRODUCT_DAILY_LOAD.py
# Purpose     : Daily job to update product information from CAPS export placed in S3
#  Date         : Who:            What:
#  12-12-2018     jgali3          Added Slack failure,remove email on success
#  12-17-2018    jgali3           added start and success tasks per request from forecast team
#  05-17-2019    hkoner           Parameterized bash operator
#========================================================================================================

# --- Imports
# -----------------------------------------------------------------------
from datetime import date,datetime, timedelta
from airflow.operators import  SnowFlakeOperator, SlackOperator, BashOperator, DummyOperator
from airflow.models import Variable, DAG, DagRun
from airflow.operators import ComputeBashOperator
# DAG Specific parameters and variables
#-----------------------------------------------------------------------
dag_name = 'DDS_NA_CAPS_PRODUCT_DAILY_LOAD'
schedule = '0 5 * * *' # Every day 5 AM UTC / 9 PM PST
snowflake_conn = "snowflake_idap"
start_date = datetime(2019, 05, 20)
idap_db = Variable.get("idap_sf_db")
idap_role = Variable.get("idap_sf_role")
idap_wh = Variable.get("idap_sf_wh")
dds_stg_schema = "DDS_STAGE"
dds_xform_schema = "DDS_XFORM"
idapbucket = Variable.get("idap_s3_bucket")
ngapbucket = Variable.get("ngap_s3_bucket")
demandbucket = Variable.get("dsmdemand_s3_bucket")
ngapenv= Variable.get("env")
slack_channel = Variable.get("idap_alerts_slack_channel")
sf_file_format_name = 'COMMA_DELIMITER'
sf_input_s3_folder = 'DSMDEMAND'


############################
# On failure function
############################
failure_notification = SlackOperator(
    task_id='slack_notification_failure',
    channel=slack_channel,
    message='The dag ' + dag_name + ' has failed!'
).execute


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': start_date,
    'on_failure_callback':failure_notification,
    'retries': 0,
}

dag = DAG( dag_name, default_args=default_args, schedule_interval= schedule ,concurrency=1,max_active_runs=1)

# Start Task
#----------------------------------------------------------------
start_task = DummyOperator(task_id='start_task', dag=dag)

# Executing Slack Messages
# -------------------------------------------------------
slack_message_start = SlackOperator(
    task_id='slack_notification_start',
    channel=slack_channel,
    depends_on_past=False,
    wait_for_downstream=False,
    message= '{dag_name} has been successfully started.'.format(dag_name = dag_name),
    dag=dag)


# Loading CAPS Product daily
# -------------------------------------------------------
s3_sql_dir = '/usr/local/airflow/code/dds_na_caps_product.sql'
sf_sql_load_idap_product = SnowFlakeOperator(
        task_id='load_caps_product_snowflake',
        provide_context=True,
        conn_id = snowflake_conn,
        sql_file = s3_sql_dir,
        parameters={'ROLE_NAME': idap_role,
                'WAREHOUSE_NAME': idap_wh,
                'DB_NAME': idap_db,
                'STG_SCHEMA_NAME': dds_stg_schema,
                'TGT_SCHEMA_NAME': dds_xform_schema,
                'DSMDEMAND': sf_input_s3_folder,
                'FILE_FORMAT': sf_file_format_name},
        dag=dag)


# Task to copy files from one S3 to other S3 location
#commented the following section by Sunil as not one using file in dsmidap0x7c3442-prd-us-east-1.
#----------------------------------------------------------------
#bash_cmd = 'aws s3 cp s3://{demandbucket}/data/application/catalog-export/delivery/ s3://{idapbucket}/archive/application/dds/catalog/ --recursive --exclude "*" --include "ITEM_MAPPING_*" --acl bucket-owner-full-control'.format(demandbucket=demandbucket,idapbucket=idapbucket)
#copy_mapping_file = ComputeBashOperator(
#    task_id='copy_mapping_file',
#    bash_command=bash_cmd,
#    dag=dag)

# Executing slack success notify
# -------------------------------------------------------
slack_message_success = SlackOperator(
    task_id='slack_notification_success',
    channel=slack_channel,
    depends_on_past=False,
    wait_for_downstream=False,
    message= '{dag_name} has been successfully completed.'.format(dag_name = dag_name),
    dag=dag)


# End Task
#----------------------------------------------------------------
end_task = DummyOperator(task_id='end_task', dag=dag)

#start_task>>slack_message_start>>sf_sql_load_idap_product>>copy_mapping_file>>slack_message_success>>end_task
start_task>>slack_message_start>>sf_sql_load_idap_product>>slack_message_success>>end_task