from datetime import datetime, timedelta
import json

from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmrOperator, \
    SparkOperator, SlackOperator, \
    BatchEndOperator, PythonOperator, GenieHiveOperator
from airflow.operators.dummy_operator import DummyOperator

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_PRODUCT_BY_GEO_REFRESH_JOB'
start_date = datetime(2020, 3, 3, 18, 0, 0)
schedule_interval = '0 18 * * *'
lpo_email = Variable.get("lpo_sas_status_mail")
lpo_pager_duty = Variable.get("lpo_pager_duty")
slack_channel = Variable.get("lpo_slack_alerts")
lpo_commons_env = Variable.get("lpo_commons_env") # One of: sbx, non, prd
env = Variable.get("lpo_env")
cluster_name = env + '-lpo-product-by-geo-refresh'
bucket = Variable.get("ngap_s3_bucket")
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'

# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': start_date,
    'email': [lpo_email, lpo_pager_duty],
    'email_on_failure': lpo_email_on_failure,
    'email_on_retry': False,
    'retries': 0,
    'catchup': False,
    'retry_delay': timedelta(minutes=10)
}

dag = DAG(dag_name, default_args=default_args, schedule_interval=schedule_interval, concurrency=1, max_active_runs=1)

default_queue = 'airflow'

############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel, message='product_by_geo_refresh has failed.').execute(context)

start = DummyOperator(
    task_id='initialize',
    queue=default_queue,
    retries=5,
    retry_delay=timedelta(seconds=15),
    dag=dag)

task_emr_spinup = EmrOperator(
    task_id='emr_spinup',
    cluster_action='spinup',
    cluster_name=cluster_name,
    num_core_nodes=4,
    num_task_nodes=3,
    queue=default_queue,
    classification='bronze',
    core_inst_type='r5d.4xlarge',
    task_inst_type='r5d.4xlarge',
    project_id='FY160072.02-LPO',
    emr_version='5.29.0',
    bootstrap_actions=[
        {
            'Name': 'EMR Bootstrap Install Pandas and BOTO3',
            'ScriptBootstrapAction': {
                'Path': 's3://{0}/{1}/dstiengineering-lpo/airflow_deploy/scripts/pandasboto3install.sh'.format(bucket, env),
                'Args': []
            }
        },
        {
            'Name': 'EMR Bootstrap Install Splunk Logging Handler',
            'ScriptBootstrapAction': {
                'Path': 's3://{0}/{1}/dstiengineering-lpo/airflow_deploy/scripts/splunkinstall.sh'.format(bucket, env),
                'Args': []
            }
        }
    ],
    retries=5,
    retry_delay=timedelta(seconds=15),
    dag=dag)

spark_submit_parameters = {
    'env_name': lpo_commons_env,
    'product_by_geo_env': 'product_by_geo_env.prop',
    'splunk_properties': 'splunk_properties.prop'
}

spark_command = '--executor-memory 12G --driver-memory 12G --executor-cores 2 --num-executors 18 ' \
                          ' --conf spark.yarn.executor.extraClassPath=./ --conf fs.s3n.multipart.uploads.enabled=true ' \
                          ' --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 ' \
                          ' --conf spark.yarn.maxAppAttempts=1' \
                          ' --files s3://' + bucket + '/' + env + '/dstiengineering-lpo/prop/product_by_geo_env.prop,s3://' + bucket + '/' + env + '/dstiengineering-lpo/prop/splunk_properties.prop ' \
                          ' --py-files s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/python/lpo_common_functions.py,s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/spark/load_product_by_geo.py ' \
                          ' s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/spark/load_product_by_geo_sqs_driver.py "' + json.dumps(spark_submit_parameters) + '"'


spark_operator = SparkOperator(
    task_id='product_by_geo_refresh_task',
    command=spark_command,
    job_name="product_by_geo_refresh",
    queue=default_queue,
    sched_type=cluster_name,
    on_failure_callback=failurecallback,
    dag=dag)

task_emr_terminate = EmrOperator(
    task_id='emr_terminate',
    cluster_action='terminate',
    cluster_name=cluster_name,
    queue=default_queue,
    dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='product_by_geo_refresh has successfully completed.',
    dag=dag)

end = BatchEndOperator(
    queue=default_queue,
    dag=dag)

start.set_downstream(task_emr_spinup)
task_emr_spinup.set_downstream(spark_operator)
spark_operator.set_downstream(task_emr_terminate)
task_emr_terminate.set_downstream(slack_alerts)
slack_alerts.set_downstream(end)
start.set_downstream(end)
