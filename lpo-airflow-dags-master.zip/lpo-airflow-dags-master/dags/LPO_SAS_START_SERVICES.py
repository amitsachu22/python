#========================================================================================================
# Script Name : LPO_GC_SAS_START_SERVICES_JOB
#========================================================================================================

import datetime
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.models import DAG
from airflow.models import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.email_operator import EmailOperator
from airflow.operators import SlackOperator


# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SAS_START_SERVICES_JOB'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
schedule_interval = None
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'
lpo_pager_duty = Variable.get("lpo_pager_duty")


# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2020, 5, 31),
    'email': [lpo_email, lpo_pager_duty],
    'email_on_failure': lpo_email_on_failure,
    'email_on_retry': False,
    #'retries': 4,
    #'retry_delay': timedelta(seconds=15),
    'catchup': False
}


dag = DAG('LPO_SAS_START_SERVICES_JOB', default_args=default_args, schedule_interval=None, concurrency=1,
          max_active_runs=1)


############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='sas start services has failed.').execute(context)


start = DummyOperator(
    task_id='start',
    retries=5,
    retry_delay=datetime.timedelta(seconds=15),
    dag=dag)

sas_studio = SSHOperator(task_id='sas_studio',
                                ssh_conn_id='lpo_Prog',
                                command="sudo systemctl start sas-viya-sasstudio-default ",
                                trigger_rule='all_success',
                                on_failure_callback=failurecallback,
                                dag=dag)

sas_studiov = SSHOperator(task_id='sas_studiov',
                                 ssh_conn_id='lpo_Prog',
                                 command="sudo systemctl start sas-viya-studiov-default  ",
                                 trigger_rule='all_success',
                                 on_failure_callback=failurecallback,
                                 dag=dag)

sas_visual_analytics = SSHOperator(task_id='sas_visual_analytics',
                                         ssh_conn_id='lpo_visual',
                                          command="sudo systemctl start sas-viya-sasvisualanalytics-default ",
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

sas_data_studio = SSHOperator(task_id='sas_data_studio',
                                    ssh_conn_id='lpo_visual',
                                     command="sudo systemctl start sas-viya-datastudio-default ",
                                     trigger_rule='all_success',
                                     on_failure_callback=failurecallback,
                                     dag=dag)

sas_report_viewer = SSHOperator(task_id='sas_report_viewer',
                                      ssh_conn_id='lpo_visual',
                                       command="sudo systemctl start sas-viya-sasreportviewer-default ",
                                       trigger_rule='all_success',
                                       on_failure_callback=failurecallback,
                                       dag=dag)

sas_graph_builder = SSHOperator(task_id='sas_graph_builder',
                                      ssh_conn_id='lpo_visual',
                                       command="sudo systemctl start sas-viya-sasgraphbuilder-default ",
                                       trigger_rule='all_success',
                                       on_failure_callback=failurecallback,
                                       dag=dag)

sas_drive = SSHOperator(task_id='sas_drive',
                              ssh_conn_id='lpo_visual',
                               command="sudo systemctl start sas-viya-drive-default ",
                               trigger_rule='all_success',
                               on_failure_callback=failurecallback,
                               dag=dag)


############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='sas start services has been successfully completed.',
    dag=dag)


############################
# Email Notification
############################
email_notify = EmailOperator(
    task_id='job_status_email_notification',
    to=lpo_email,
    subject='DAG SAS_START_SERVICES_JOB',
    html_content="<p>Hi,</p><p>sas start services is completed successfully.</p><p>Thanks,</p><p>LPO Team.</p>",
    dag=dag)


All_done = DummyOperator(
    task_id='finished_sas_start_services',
    trigger_rule='all_success',
    dag=dag)


start.set_downstream(sas_studio)
sas_studio.set_downstream(sas_studiov)
sas_studiov.set_downstream(sas_visual_analytics)
sas_visual_analytics.set_downstream(sas_data_studio)
sas_data_studio.set_downstream(sas_report_viewer)
sas_report_viewer.set_downstream(sas_graph_builder)
sas_graph_builder.set_downstream(sas_drive)
sas_drive.set_downstream(slack_alerts)
slack_alerts.set_downstream(email_notify)
email_notify.set_downstream(All_done)
