#========================================================================================================
# Script Name : LPO_GC_SAS_WEEKLY_JOB
#========================================================================================================

import pprint

import datetime
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.models import DAG
from airflow.operators import EmailOperator, TriggerDagRunOperator, SlackOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.models import Variable

pp = pprint.PrettyPrinter(indent=4)

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SAS_WEEKLY_MAINTENANCE_JOB'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
schedule_interval = None
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'
lpo_pager_duty = Variable.get("lpo_pager_duty")

# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2020, 5, 31),
    'email': [lpo_email, lpo_pager_duty],
    'email_on_failure': lpo_email_on_failure,
    'email_on_retry': False,
    #'retries': 0,
    #'retry_delay': datetime.timedelta(minutes=30),
    'catchup': False
}


dag = DAG('LPO_SAS_WEEKLY_MAINTENANCE_JOB', default_args=default_args, schedule_interval=None, concurrency=1, max_active_runs=1)



############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='sas weekly maintenance services job has failed.').execute(context)

def conditionally_trigger(context, dag_run_obj):
    """This function decides whether or not to Trigger the remote DAG"""
    c_p = context['params']['condition_param']
    print("Controller DAG : conditionally_trigger = {}".format(c_p))
    if context['params']['condition_param']:
        dag_run_obj.payload = {'message': context['params']['message']}
        pp.pprint(dag_run_obj.payload)
        return dag_run_obj



clean_sas_job = SSHOperator(task_id='clean_sas_job',
                                   ssh_conn_id='lpo_Prog',
                                   command="sudo /opt/sas/fes/LoadMgr/util/cleanwork.sh ",
                                   trigger_rule='all_success',
                                   on_failure_callback=failurecallback,
                                   dag=dag)

# fact_purge = SSHOperator(task_id='fact_purge',
#                                 ssh_conn_id='lpo_Prog',
#                                 command="sh /opt/sas/fes/LoadMgr/util/process_fact_purge.sh 0 ",
#                                 trigger_rule='all_success',
#                                 on_failure_callback=failurecallback,
#                                 dag=dag)

log_cleanup = SSHOperator(task_id='log_cleanup',
                                 ssh_conn_id='lpo_Prog',
                                 command="/opt/sas/fes/LoadMgr/util/log_cleanup.sh ",
                                 trigger_rule='all_success',
                                 on_failure_callback=failurecallback,
                                 dag=dag)

# output_cleanup = SSHOperator(task_id='output_cleanup',
#                                     ssh_conn_id='lpo_Prog',
#                                     command="sh /opt/sas/fes/LoadMgr/util/export_purge.sh ",
#                                     trigger_rule='all_success',
#                                     on_failure_callback=failurecallback,
#                                     dag=dag)

sas_sfc_trigger = TriggerDagRunOperator(task_id='Trigger_SAS_file_extract',
                                        trigger_dag_id="LPO_SAS_WEEKLY_FILE_EXTRACT_JOB",
                                        python_callable=conditionally_trigger,
                                        params={'condition_param': True,
                                                'message': 'Trigger the LPO_SAS_WEEKLY_FILE_EXTRACT_JOB'},
                                        trigger_rule='all_success',
                                        on_failure_callback=failurecallback,
                                        dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='sas weekly maintenance services job has been successfully completed.',
    dag=dag)



############################
# Email Notification
############################
email_notify = EmailOperator(
    task_id='job_status_email_notification',
    to=lpo_email,
    subject='DAG SAS_WEEKLY_MAINTENANCE_JOB',
    html_content="<p>Hi,</p><p>sas weekly maintenance services is completed successfully.</p><p>Thanks,</p><p>LPO Team.</p>",
    dag=dag)

All_done = DummyOperator(
    task_id='finished_weekly_maintenance',
    trigger_rule='all_success',
    dag=dag)


clean_sas_job.set_downstream(log_cleanup)
#fact_purge.set_downstream(log_cleanup)
log_cleanup.set_downstream(sas_sfc_trigger)
#output_cleanup.set_downstream(slack_alerts)
sas_sfc_trigger.set_downstream(slack_alerts)
slack_alerts.set_downstream(email_notify)
email_notify.set_downstream(All_done)
