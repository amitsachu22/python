#========================================================================================================
# Script Name : IDAP_DTC_PRODUCT_MASTER_WEEKLY_LOAD
#
# Purpose: It exports product data to S3 for validation
#
# Created By: Masa Watanabe, Matthew Piekarski
#========================================================================================================

# --- Imports
# -----------------------------------------------------------------------

import pprint
from airflow import DAG, settings
from airflow.operators import EmailOperator, DummyOperator, SnowFlakeOperator, SlackOperator, BatchStartOperator, BatchEndOperator
from datetime import datetime, timedelta
from airflow.models import Variable, DAG, DagRun
from boto.s3.key import Key
from airflow.utils.state import State

pp = pprint.PrettyPrinter(indent=4)  

# DAG Specific parameters and variables
#-----------------------------------------------------------------------
dag_name = 'IDAP_DTC_PRODUCT_MASTER_WEEKLY_LOAD'
dag_concurrency = 1    # how many tasks max per DAG
dag_max_active_runs = 1    # concurrently how many instances can run of the DAG
dag_concurrency_pool = ''    # Add in Airflow > Admin > Pools
schedule_interval = '0 11 * * 6'    #3AM PST every Saturday
success_message_html = "<p>Hi,</p><p>Product master job completed successfully.</p><p>Thanks,</p><p>DDS Team.</p>" #
main_reporting_email = Variable.get("sas_failure_email")
cc_reporting_email = '' 
slack_channel = Variable.get("idap_alerts_slack_channel")

#Airflow variables
#-----------------------------------------------------------------------
bucket = Variable.get("ngap_s3_bucket")
idap_db = Variable.get("idap_sf_db")
dtc_db = Variable.get("dtc_sf_db")
idap_role = Variable.get("idap_sf_role")
dtc_role = Variable.get("idap_sf_dtc_role") 
idap_wh = Variable.get("idap_sf_wh")
env = Variable.get("env")

#Snowflake variables
#-----------------------------------------------------------------------
snowflake_conn = 'snowflake_idap' 
idap_stg_schema = "IDAP_STG_T"
idap_view_schema = "IDAP_ETL_V"
idap_target_schema = "IDAP_T"
dtc_schema = 'DTC_REFERENCE' #Added schema name parameter
sf_file_format_name = 'IDAP_ETL_V_PIPE_DELIMITED_FILE'
sf_file_name = 'IDAP_NA/SALES/RDF_PRODUCT_MASTER_EXPORT.csv.gz'
sf_output_s3_folder = 'DSMIDAP_IDAP_ETL_V'
default_queue = 'airflow'

# Airflow default DAG parameters
# -------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2020, 6, 23, 0, 0, 0),
    'email': [ main_reporting_email ],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=5),
    'catchup': False

}

dag = DAG(dag_name, 
    default_args=default_args, 
    schedule_interval= schedule_interval,
    concurrency=dag_concurrency,
    max_active_runs=dag_max_active_runs)


############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='Product Master Weekly has failed.').execute(context)

# Just for UI - Does nothing
# -------------------------------------------------------
Start_Task = DummyOperator(
    task_id='start',
    queue=default_queue,
    catch_up=True,
    retries=3,
    dag=dag)


# Find SQL files and execute tasks
# -------------------------------------------------------
# SQL will delete records in DTC_PRODUCT_MASTER_STG table and insert records from DTC_PRODUCT_MASTER_GTIN into the table 
s3_sql_dir = '/usr/local/airflow/code/DTC_PRODUCT_MASTER_INSERT_DELETE.sql'
sf_sql_insert_delete = SnowFlakeOperator(
        task_id='DSM_DEMAND_DTC_PRODUCT_MASTER_INSERT_DELETE',
        provide_context=True,
        conn_id = snowflake_conn,
        sql_file = s3_sql_dir,
        parameters={'DB_NAME_IDAP': idap_db,
                    'SCHEMA_NAME_IDAP_STG': idap_stg_schema,
                    'SCHEMA_NAME_IDAP_V': idap_view_schema,
                    'SCHEMA_NAME_IDAP_T': idap_target_schema,
                    'WH_NAME_IDAP': idap_wh,
                    'ROLE_NAME_IDAP': dtc_role,
                    'DB_NAME_DTC': dtc_db,
                    'SCHEMA_NAME_DTC': dtc_schema
                     },
        on_failure_callback=failurecallback,
        dag=dag)

# SQL file will upload the new table into a csv file in S3
s3_sql_dir2 = '/usr/local/airflow/code/DTC_PRODUCT_UPLOAD.sql'
sf_sql_upload = SnowFlakeOperator(
        task_id='DSM_DEMAND_DTC_PRODUCT_MASTER_UPLOAD',
        provide_context=True,
        conn_id = snowflake_conn,
        sql_file = s3_sql_dir2,
        parameters={'DB_NAME_IDAP': idap_db,
                    'SCHEMA_NAME_IDAP_STG': idap_stg_schema,
                    'SCHEMA_NAME_IDAP_V': idap_view_schema,
                    'SCHEMA_NAME_IDAP_T': idap_target_schema,
                    'WH_NAME_IDAP': idap_wh,
                    'ROLE_NAME_IDAP': idap_role,
                    'IDAP_ETL_V_PIPE_DELIMITED_FORMAT': sf_file_format_name,
                    'FILE_NAME': sf_file_name,
                    'S3_OUTPUT_FOLDER': sf_output_s3_folder
                    },
        on_failure_callback=failurecallback,
         dag=dag)

# SQL file will upload the new table into a csv file in S3
s3_sql_dir3 = '/usr/local/airflow/code/DTC_PRODUCT_MASTER_ITEM_EXPORT.sql'
sf_item_upload = SnowFlakeOperator(
    task_id='DSM_DEMAND_DTC_ITEM_MASTER_EXPORT',
    provide_context=True,
    conn_id = snowflake_conn,
    sql_file = s3_sql_dir3,
    parameters={'DB_NAME_IDAP': idap_db,
                'WH_NAME_IDAP': idap_wh,
                'ROLE_NAME_DTC': dtc_role
                },
    on_failure_callback=failurecallback,
    dag=dag)

# Executing Slack Messages
# -------------------------------------------------------
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    depends_on_past=False,
    wait_for_downstream=False,
    message= '{dag_name} has been successfully completed.'.format(dag_name = dag_name),
    dag=dag)

# Executing Email Notification
# -------------------------------------------------------
emailNotify = EmailOperator(
   task_id='email_update',
   to = main_reporting_email,
   cc= cc_reporting_email,
   subject = '{dag_name} completed successfully in {env}'.format(dag_name = dag_name, env = env),
   html_content = success_message_html,
   dag=dag
)


#Justt for UI - Does nothing
#-------------------------------------------------------

End_task = DummyOperator(
    task_id='success',
    queue=default_queue,
    retries=3,
    retry_delay=timedelta(seconds=90),
    dag=dag)

Start_Task>>sf_sql_insert_delete>>sf_sql_upload>>sf_item_upload>>slack_alerts>>emailNotify>>End_task
