#========================================================================================================
# Script Name : LPO_GC_SAS_DAILY_STOP_SERVICES_JOB
#========================================================================================================

import pprint

import datetime
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.models import DAG
from airflow.operators import EmailOperator, TriggerDagRunOperator, SlackOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.models import Variable

pp = pprint.PrettyPrinter(indent=4)


# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SAS_HISTORIC_START_PROCESS_JOB'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
schedule_interval = None
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'
lpo_pager_duty = Variable.get("lpo_pager_duty")

# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2020, 5, 31),
    'email': lpo_email,
    'email_on_failure': True,
    'email_on_retry': False,
    #'retries': 0,
    #'retry_delay': timedelta(minutes=30),
    'catchup': False
}

dag = DAG('LPO_SAS_HISTORIC_START_PROCESS_JOB', default_args=default_args, schedule_interval=None, concurrency=1, max_active_runs=1)


############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='sas stop services has failed.').execute(context)

def conditionally_trigger(context, dag_run_obj):
    """This function decides whether or not to Trigger the remote DAG"""
    c_p = context['params']['condition_param']
    print("Controller DAG : conditionally_trigger = {}".format(c_p))
    if context['params']['condition_param']:
        dag_run_obj.payload = {'message': context['params']['message']}
        pp.pprint(dag_run_obj.payload)
        return dag_run_obj


sas_studio = SSHOperator(task_id='sas_studio',
                                ssh_conn_id='lpo_Prog',
                               command="sudo systemctl stop sas-viya-sasstudio-default ",
                                trigger_rule='all_success',
                                on_failure_callback=failurecallback,
                                dag=dag)

sas_studiov = SSHOperator(task_id='sas_studiov',
                                 ssh_conn_id='lpo_Prog',
                                command="sudo systemctl stop sas-viya-studiov-default  ",
                                 trigger_rule='all_success',
                                 on_failure_callback=failurecallback,
                                 dag=dag)

sas_visual_analytics = SSHOperator(task_id='sas_visual_analytics',
                                          ssh_conn_id='lpo_visual',
                                         command="sudo systemctl stop sas-viya-sasvisualanalytics-default ",
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

sas_data_studio = SSHOperator(task_id='sas_data_studio',
                                     ssh_conn_id='lpo_visual',
                                    command="sudo systemctl stop sas-viya-datastudio-default ",
                                     trigger_rule='all_success',
                                     on_failure_callback=failurecallback,
                                     dag=dag)

sas_report_viewer = SSHOperator(task_id='sas_report_viewer',
                                       ssh_conn_id='lpo_visual',
                                      command="sudo systemctl stop sas-viya-sasreportviewer-default  ",
                                       trigger_rule='all_success',
                                       on_failure_callback=failurecallback,
                                       dag=dag)

sas_graph_builder = SSHOperator(task_id='sas_graph_builder',
                                       ssh_conn_id='lpo_visual',
                                      command="sudo systemctl stop sas-viya-sasgraphbuilder-default  ",
                                       trigger_rule='all_success',
                                       on_failure_callback=failurecallback,
                                       dag=dag)

sas_drive = SSHOperator(task_id='sas_drive',
                               ssh_conn_id='lpo_visual',
                              command="sudo systemctl stop sas-viya-drive-default  ",
                               trigger_rule='all_success',
                               dag=dag)

sas_sfc_trigger = TriggerDagRunOperator(task_id='Trigger_SAS_data_load',
                                        trigger_dag_id="LPO_SAS_HISTORIC_DATA_LOAD_JOB",
                                        python_callable=conditionally_trigger,
                                        params={'condition_param': True,
                                                'message': 'Trigger the LPO_SAS_HISTORIC_DATA_LOAD_JOB'},
                                        trigger_rule='all_success',
                                        on_failure_callback=failurecallback,
                                        dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='sas historic stop services has been successfully completed.',
    dag=dag)


############################
# Email Notification
############################
email_notify = EmailOperator(
    task_id='job_status_email_notification',
    to=lpo_email,
    subject='DAG SAS_HISTORIC_STOP_SERVICES_JOB',
    html_content="<p>Hi,</p><p>Job is completed successfully.</p><p>Thanks,</p><p>LPO Team.</p>",
    dag=dag)

All_done = DummyOperator(
    task_id='finished_sas_historic_stop_services',
    trigger_rule='all_success',
    dag=dag)


sas_studio.set_downstream(sas_studiov)
sas_studiov.set_downstream(sas_visual_analytics)
sas_visual_analytics.set_downstream(sas_data_studio)
sas_data_studio.set_downstream(sas_report_viewer)
sas_report_viewer.set_downstream(sas_graph_builder)
sas_graph_builder.set_downstream(sas_drive)
sas_drive.set_downstream(sas_sfc_trigger)
sas_sfc_trigger.set_downstream(slack_alerts)
slack_alerts.set_downstream(email_notify)
email_notify.set_downstream(All_done)
