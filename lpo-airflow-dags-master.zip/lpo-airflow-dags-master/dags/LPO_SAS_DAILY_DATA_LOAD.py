#========================================================================================================
# Script Name : LPO_GC_SAS_DAILY_JOB
#========================================================================================================

import pprint

import datetime
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmailOperator, TriggerDagRunOperator, SlackOperator
from airflow.operators.dummy_operator import DummyOperator

pp = pprint.PrettyPrinter(indent=4)

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SAS_DAILY_DATA_LOAD_JOB'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
schedule_interval = None
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'
lpo_pager_duty = Variable.get("lpo_pager_duty")
lpo_process_env = Variable.get("lpo_process_env")

# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2020, 5, 31),
    'email': [lpo_email, lpo_pager_duty],
    'email_on_failure': lpo_email_on_failure,
    'email_on_retry': False,
    #'retries': 0,
    #'retry_delay': timedelta(minutes=30),
    'catchup': False
}

dag = DAG('LPO_SAS_DAILY_DATA_LOAD_JOB', default_args=default_args, schedule_interval=None, concurrency=1,
          max_active_runs=1)


############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='sas daily data Load is failed.').execute(context)

def conditionally_trigger(context, dag_run_obj):
    """This function decides whether or not to Trigger the remote DAG"""
    c_p = context['params']['condition_param']
    print("Controller DAG : conditionally_trigger = {}".format(c_p))
    if context['params']['condition_param']:
        dag_run_obj.payload = {'message': context['params']['message']}
        pp.pprint(dag_run_obj.payload)
        return dag_run_obj


gc_source_to_sas_stg = SSHOperator(task_id='gc_source_to_sas_stg_dly',
                                          ssh_conn_id='lpo_Prog',
                                          command="/opt/sas/fes/LoadMgr/bin/controller.sh daily_src2stg ",
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

gc_stg_data_mart = SSHOperator(task_id='gc_stg_data_mart_dly',
                                      ssh_conn_id='lpo_Prog',
                                      command="/opt/sas/fes/LoadMgr/bin/controller.sh daily_stg2dm ",
                                      trigger_rule='all_success',
                                      on_failure_callback=failurecallback,
                                      dag=dag)

export_and_transfer = SSHOperator(task_id='export_and_transfer_wkly',
                                         ssh_conn_id='lpo_Prog',
                                         command="/usr/bin/ksh /opt/sas/fes/LoadMgr/util/lpo_transfer.sh upload ",
                                         trigger_rule='all_success',
                                         on_failure_callback=failurecallback,
                                         dag=dag)

sas_start_trigger = TriggerDagRunOperator(task_id='Trigger_SAS_Start_Services',
                                          trigger_dag_id="LPO_SAS_START_SERVICES_JOB",
                                          python_callable=conditionally_trigger,
                                          params={'condition_param': True,
                                                  'message': 'Trigger the LPO_SAS_START_SERVICES_JOB'},
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='sas daily data load has been successfully completed.',
    dag=dag)



############################
# Email Notification
############################
email_notify = EmailOperator(
    task_id='job_status_email_notification',
    to=lpo_email,
    subject='DAG SAS_DAILY_DATA_LOAD_JOB',
    html_content="<p>Hi,</p><p>sas daily data load is completed successfully.</p><p>Thanks,</p><p>LPO Team.</p>",
    dag=dag)


lpo_processing_status = SSHOperator(task_id='lpo_processing_status',
                                          ssh_conn_id='lpo_Prog',
                                          command='/usr/bin/ksh /home/a.etlusr/lpo_processing_status.sh {lpo_process_env} '.format(lpo_process_env=lpo_process_env),
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

All_done = DummyOperator(
    task_id='finished_daily',
    trigger_rule='all_success',
    dag=dag)


gc_source_to_sas_stg.set_downstream(gc_stg_data_mart)
gc_stg_data_mart.set_downstream(export_and_transfer)
export_and_transfer.set_downstream(slack_alerts)
slack_alerts.set_downstream(sas_start_trigger)
sas_start_trigger.set_downstream(email_notify)
email_notify.set_downstream(lpo_processing_status)
lpo_processing_status.set_downstream(All_done)
