#========================================================================================================
# Script Name : LPO_GC_SAS_HISTORIC_DATA_LOAD_JOB
#========================================================================================================

import pprint

import datetime
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmailOperator, TriggerDagRunOperator, SlackOperator
from airflow.operators.dummy_operator import DummyOperator


# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SAS_HISTORIC_DATA_JOB'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
schedule_interval = None
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'
lpo_pager_duty = Variable.get("lpo_pager_duty")

pp = pprint.PrettyPrinter(indent=4)


# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2020, 5, 31),
    'email': lpo_email,
    'email_on_failure': True,
    'email_on_retry': False,
    #'retries': 0,
    #'retry_delay': timedelta(minutes=30),
    'catchup': False
}

dag = DAG('LPO_SAS_HISTORIC_DATA_LOAD_JOB', default_args=default_args, schedule_interval=None, concurrency=1,
          max_active_runs=1)


############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='sas historic data load job has failed.').execute(context)

def conditionally_trigger(context, dag_run_obj):
    """This function decides whether or not to Trigger the remote DAG"""
    c_p = context['params']['condition_param']
    print("Controller DAG : conditionally_trigger = {}".format(c_p))
    if context['params']['condition_param']:
        dag_run_obj.payload = {'message': context['params']['message']}
        pp.pprint(dag_run_obj.payload)
        return dag_run_obj



seed_tables = SSHOperator(task_id='gc_parallel_demand_forecasting_hsty',
                                 ssh_conn_id='lpo_Prog',
                                command="/opt/sas/fes/LoadMgr/bin/controller.sh seed_tables ",
                                 trigger_rule='all_success',
                                 on_failure_callback=failurecallback,
                                 dag=dag)

gc_source_to_sas_stg = SSHOperator(task_id='gc_source_to_sas_stg_hsty',
                                          ssh_conn_id='lpo_Prog',
                                         command="/opt/sas/fes/LoadMgr/bin/controller.sh hist_src2stg ",
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

gc_stg_data_mart = SSHOperator(task_id='gc_stg_data_mart_hsty',
                                      ssh_conn_id='lpo_Prog',
                                     command="/opt/sas/fes/LoadMgr/bin/controller.sh hist_stg2dm_global ",
                                      trigger_rule='all_success',
                                      on_failure_callback=failurecallback,
                                      dag=dag)

sas_start_trigger = TriggerDagRunOperator(task_id='Trigger_SAS_Start_Services',
                                          trigger_dag_id="LPO_SAS_START_SERVICES_JOB",
                                          python_callable=conditionally_trigger,
                                          params={'condition_param': True,
                                                  'message': 'Trigger the LPO_SAS_START_SERVICES_JOB'},
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='sas historic dta load job has successfully completed.',
    dag=dag)


############################
# Email Notification
############################
email_notify = EmailOperator(
    task_id='job_status_email_notification',
    to=lpo_email,
    subject='DAG SAS_historic_JOB',
    html_content="<p>Hi,</p><p>Job is completed successfully.</p><p>Thanks,</p><p>LPO Team.</p>",
    dag=dag)

All_done = DummyOperator(
    task_id='finished_historic_data_load',
    trigger_rule='all_success',
    dag=dag)


seed_tables.set_downstream(gc_source_to_sas_stg)
gc_source_to_sas_stg.set_downstream(gc_stg_data_mart)
gc_stg_data_mart.set_downstream(sas_start_trigger)
sas_start_trigger.set_downstream(slack_alerts)
slack_alerts.set_downstream(email_notify)
email_notify.set_downstream(All_done)
