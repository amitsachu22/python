from datetime import datetime, timedelta
import json

from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmrOperator, \
    SparkOperator, SlackOperator, \
    BatchEndOperator, PythonOperator, GenieHiveOperator
from airflow.operators.dummy_operator import DummyOperator

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SALES_DAILY_EXPORT_JOB'
start_date = datetime(2020, 3, 3, 16, 0, 0)
schedule_interval = '0 16 * * *'
lpo_email = Variable.get("lpo_sas_status_mail")
lpo_pager_duty = Variable.get("lpo_pager_duty")
slack_channel = Variable.get("lpo_slack_alerts")
lpo_commons_env = Variable.get("lpo_commons_env") # One of: sbx, non, prd
env = Variable.get("lpo_env")
cluster_name = env + '-lpo-sales-daily-export'
bucket = Variable.get("ngap_s3_bucket")
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'

# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': start_date,
    'email': [lpo_email, lpo_pager_duty],
    'email_on_failure': lpo_email_on_failure,
    'email_on_retry': False,
    'retries': 0,
    'catchup': False,
    'retry_delay': timedelta(minutes=10)
}

dag = DAG(dag_name, default_args=default_args, schedule_interval=schedule_interval, concurrency=1, max_active_runs=1)

default_queue = 'airflow'

############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel, message='sales export has failed.').execute(context)

start = DummyOperator(
    task_id='sales_delta_process',
    queue=default_queue,
    retries=5,
    retry_delay=timedelta(seconds=15),
    dag=dag)

task_emr_spinup = EmrOperator(
    task_id='emr_spinup',
    cluster_action='spinup',
    cluster_name=cluster_name,
    num_core_nodes=4,
    num_task_nodes=3,
    queue=default_queue,
    classification='bronze',
    core_inst_type='r5d.4xlarge',
    task_inst_type='r5d.4xlarge',
    project_id='FY160072.02-LPO',
    emr_version='5.29.0',
    bootstrap_actions=[
        {
            'Name': 'EMR Bootstrap Install Pandas and BOTO3',
            'ScriptBootstrapAction': {
                'Path': 's3://{0}/{1}/dstiengineering-lpo/airflow_deploy/scripts/pandasboto3install.sh'.format(bucket, env),
                'Args': []
            }
        },
        {
            'Name': 'EMR Bootstrap Install Splunk Logging Handler',
            'ScriptBootstrapAction': {
                'Path': 's3://{0}/{1}/dstiengineering-lpo/airflow_deploy/scripts/splunkinstall.sh'.format(bucket, env),
                'Args': []
            }
        }
    ],
    retries=5,
    retry_delay=timedelta(seconds=15),
    dag=dag)

sales_process_dict = {
    'env_name': lpo_commons_env,
    'sales_load': 'sales_load.prop',
    'env_properties': 'sales_environment.prop',
    'splunk_properties': 'splunk_properties.prop'
}

# r5d.2xlarge	8 vCPU	61 G Memory x 5 instanves = 40 cores, 305 memory
# 2 cores per executor, 40/2-1 = 19 executors

sales_process_spark_cmd = '--executor-memory 12G --driver-memory 12G --executor-cores 2 --num-executors 18 ' \
                          ' --conf spark.yarn.executor.extraClassPath=./ --conf fs.s3n.multipart.uploads.enabled=true ' \
                          ' --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 ' \
                          ' --conf spark.yarn.maxAppAttempts=1' \
                          ' --files s3://' + bucket + '/' + env + '/dstiengineering-lpo/prop/sales_load.prop,s3://' + bucket + '/' + env + '/dstiengineering-lpo/prop/sales_environment.prop,s3://' + bucket + '/' + env + '/dstiengineering-lpo/prop/splunk_properties.prop' \
                          ' --py-files s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/python/lpo_common_functions.py,s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/python/export2thecommons.py ' \
                          ' s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/spark/export_stg_sales.py "' + json.dumps(sales_process_dict) + '"'


sales_load_processing = SparkOperator(
    task_id='sales_load_processing',
    command=sales_process_spark_cmd,
    job_name="sales_load_processing",
    queue=default_queue,
    sched_type=cluster_name,
    retries=5,
    retry_delay=timedelta(seconds=15),
    on_failure_callback=failurecallback,
    dag=dag)

task_emr_terminate = EmrOperator(
    task_id='emr_terminate',
    cluster_action='terminate',
    cluster_name=cluster_name,
    queue=default_queue,
    dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='sales export has successfully completed.',
    dag=dag)

end = BatchEndOperator(
    queue=default_queue,
    dag=dag)

start.set_downstream(task_emr_spinup)
task_emr_spinup.set_downstream(sales_load_processing)
sales_load_processing.set_downstream(task_emr_terminate)
task_emr_terminate.set_downstream(slack_alerts)
slack_alerts.set_downstream(end)
start.set_downstream(end)
