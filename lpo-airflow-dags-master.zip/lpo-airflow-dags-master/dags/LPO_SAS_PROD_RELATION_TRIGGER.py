#========================================================================================================
# Script Name : LPO_SAS_PROD_RELATION_TRIGGER
#========================================================================================================

import pprint
import datetime
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmailOperator, TriggerDagRunOperator, SlackOperator
from airflow.operators.dummy_operator import DummyOperator

pp = pprint.PrettyPrinter(indent=4)

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SAS_PROD_RELATION_TRIGGER'
dag_concurrency = 1  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
schedule_interval = None
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
s3_Connection = 's3_Conn_lpo'
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'
lpo_pager_duty = Variable.get("lpo_pager_duty")

# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2020, 5, 31),
    'email': [lpo_email, lpo_pager_duty],
    'email_on_failure': lpo_email_on_failure,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': datetime.timedelta(minutes=30),
    'catchup': False
}


dag = DAG('LPO_SAS_PROD_RELATION_TRIGGER', default_args=default_args, schedule_interval='00 14 * * 5', concurrency=1, max_active_runs=1)

default_queue = 'airflow'

############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='LPO_SAS_MONDAY_DOWNLOAD job has failed.').execute(context)


def conditionally_trigger(context, dag_run_obj):
    """This function decides whether or not to Trigger the remote DAG"""
    c_p = context['params']['condition_param']
    print("Controller DAG : conditionally_trigger = {}".format(c_p))
    if context['params']['condition_param']:
        dag_run_obj.payload = {'message': context['params']['message']}
        pp.pprint(dag_run_obj.payload)
        return dag_run_obj


Start_Task = DummyOperator(
    task_id='start',
    queue=default_queue,
    catch_up=True,
    retries=1,
    dag=dag)


sas_dl_trigger = TriggerDagRunOperator(task_id='LPO_SAS_PROD_RELATION',
                                        trigger_dag_id="LPO_SAS_PROD_RELATION",
                                        python_callable=conditionally_trigger,
                                        params={'condition_param': True,
                                                'message': 'Trigger the LPO_SAS_PROD_RELATION'},
                                        trigger_rule='all_success',
                                        on_failure_callback=failurecallback,
                                        dag=dag)


############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='LPO LPO_SAS_PROD_RELATION Trigger has been successfully completed.',
    dag=dag)


############################
# Email Notification
############################
email_notify = EmailOperator(
    task_id='job_status_email_notification',
    to=lpo_email,
    subject='LPO_SAS_PROD_RELATION_TRIGGER',
    html_content="<p>Hi,</p><p>Triggered the LPO_SAS_PROD_RELATION </p><p>Thanks,</p><p>LPO Team.</p>",
    dag=dag)

All_done = DummyOperator(
    task_id='finished_LPO_SAS_PROD_RELATION_TRIGGER',
    trigger_rule='all_success',
    dag=dag)


Start_Task.set_downstream(sas_dl_trigger)
sas_dl_trigger.set_downstream(slack_alerts)
slack_alerts.set_downstream(email_notify)
email_notify.set_downstream(All_done)
