from datetime import datetime, timedelta
import json

from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmrOperator, \
    SparkOperator, SlackOperator, \
    BatchEndOperator, PythonOperator, GenieHiveOperator
from airflow.operators.dummy_operator import DummyOperator

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SALES_HISTORY_EXPORT_JOB'
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
lpo_commons_env = Variable.get("lpo_commons_env") # One of: sbx, non, prd
env = Variable.get("lpo_env")
cluster_name = env + '-lpo-sales-history-export'
bucket = Variable.get("ngap_s3_bucket")

# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': lpo_email,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(seconds=15),
    'catchup': False,
    'start_date': datetime(2019, 5, 28, 10, 0, 0)
}

dag = DAG(dag_name, default_args=default_args, schedule_interval=None, concurrency=1, max_active_runs=1)

default_queue = 'airflow'

############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel, message='sales history export has failed.').execute(context)

start = DummyOperator(
    task_id='sales_delta_process',
    queue=default_queue,
    retries=5,
    retry_delay=timedelta(seconds=15),
    dag=dag)

task_emr_spinup = EmrOperator(
    task_id='emr_spinup',
    cluster_action='spinup',
    cluster_name=cluster_name,
    num_core_nodes=4,
    num_task_nodes=3,
    queue=default_queue,
    classification='bronze',
    core_inst_type='r3.2xlarge',
    task_inst_type='r3.2xlarge',
    project_id='FY160072.02-LPO',
    emr_version='5.17.0',
    bootstrap_actions=[
        {
            'Name': 'EMR Bootstrap Install Pandas and BOTO3',
            'ScriptBootstrapAction': {
                'Path': 's3://{0}/{1}/dstiengineering-lpo/airflow_deploy/scripts/pandasboto3install.sh'.format(bucket, env),
                'Args': []
            }
        }
    ],
    retries=5,
    retry_delay=timedelta(seconds=15),
    dag=dag)

sales_process_dict = {
    'app_name': 'export_stg_sales_history',
    'env_name': lpo_commons_env,
    'sales_load': 'sales_load.prop',
    'env_properties': 'sales_history_environment.prop',
    'is_full_load': True,
    'allow_gzip': True
}

sales_process_spark_cmd = '--executor-memory 12G --driver-memory 12G --executor-cores 2 --num-executors 18 ' \
                          ' --conf spark.yarn.executor.extraClassPath=./ --conf fs.s3n.multipart.uploads.enabled=true ' \
                          ' --conf spark.yarn.maxAppAttempts=1' \
                          ' --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 ' \
                          ' --files s3://' + bucket + '/' + env + '/dstiengineering-lpo/prop/sales_load.prop,s3://' + bucket + '/' + env + '/dstiengineering-lpo/prop/sales_history_environment.prop' \
                          ' --py-files s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/python/lpo_common_functions.py,s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/python/export2thecommons.py ' \
                          ' s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/spark/export_stg_sales.py "' + json.dumps(sales_process_dict) + '"'


sales_load_processing = SparkOperator(
    task_id='sales_load_processing',
    command=sales_process_spark_cmd,
    job_name="sales_load_processing",
    queue=default_queue,
    sched_type=cluster_name,
    on_failure_callback=failurecallback,
    dag=dag)

task_emr_terminate = EmrOperator(
    task_id='emr_terminate',
    cluster_action='terminate',
    cluster_name=cluster_name,
    queue=default_queue,
    dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='sales history export has successfully completed.',
    dag=dag)

end = BatchEndOperator(
    queue=default_queue,
    dag=dag)

start.set_downstream(task_emr_spinup)
task_emr_spinup.set_downstream(sales_load_processing)
sales_load_processing.set_downstream(task_emr_terminate)
task_emr_terminate.set_downstream(slack_alerts)
slack_alerts.set_downstream(end)
start.set_downstream(end)
