#========================================================================================================
# Script Name : IDAP_NA_CAPS_PRODUCT_DAILY_LOAD.py
# Purpose     : Daily job to update product information from CAPS export placed in S3 
#  Date         : Who:            What:
#  12-12-2018     jgali3          Added Slack failure,remove email on success
#  12-17-2018    jgali3           added start and success tasks per request from forecast team
#========================================================================================================

# --- Imports
# -----------------------------------------------------------------------
from datetime import date,datetime, timedelta
from airflow.operators import  SnowFlakeOperator, BatchStartOperator, BatchEndOperator, SlackOperator, EmailOperator,DummyOperator
from airflow.models import Variable, DAG, DagRun

# DAG Specific parameters and variables
#-----------------------------------------------------------------------
schedule = '0 5 * * *' # Every day 5 AM UTC / 9 PM PST 
snowflake_conn = "snowflake_idap"
start_date = datetime.now()
bucket = Variable.get("idap_s3_bucket")
idap_db = Variable.get("idap_sf_db")
dtc_db = Variable.get("dtc_sf_db")
idap_role = Variable.get("idap_sf_role")
idap_status_email=Variable.get("idap_failure_email")
all_role = Variable.get("idap_sf_role_all", default_var='ALL')
idap_wh = Variable.get("idap_sf_wh")
idap_stg_schema = "IDAP_STG_T"
idap_view_schema = "IDAP_ETL_V"
idap_target_schema = "IDAP_T"
ngapbucket = Variable.get("ngap_s3_bucket")
ngapenv= Variable.get("env")
slack_channel = Variable.get("idap_alerts_slack_channel")
dag_name = 'IDAP_NA_CAPS_PRODUCT_DAILY_LOAD'
sf_file_format_name = 'CAPS_PRODT'
sf_input_s3_folder = 'DSMDEMAND_IDAP_STG_T'
default_queue = 'airflow'
idap_email = Variable.get('sas_failure_email')
env = Variable.get("env")


failure_notification = SlackOperator(
    task_id='slack_notification_failure',
    channel=slack_channel,
    message='The dag ' + dag_name + ' has failed!'
).execute


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2020, 3, 3, 18, 0, 0),
    'email': idap_status_email,
    'email_on_failure': True,
    'email_on_retry': False,
    'on_failure_callback':failure_notification,
    'retries': 1,
    'retry_delay': timedelta(minutes=30)
}


dag = DAG( dag_name, default_args=default_args, schedule_interval= schedule ,concurrency=1,max_active_runs=1)


def send_slack_message(DAG, task_id, channel, message):
    return SlackOperator(
        task_id=task_id,
        channel=channel,
        message=message,
        dag=DAG)

start = DummyOperator(
    queue=default_queue,
    task_id='start',
    catch_up=True,
    retries=3,
    dag=dag)

success = DummyOperator(
    queue=default_queue,
    task_id='success',
    retries=3,
    retry_delay=timedelta(seconds=90),
    dag=dag)


s3_sql_dir = '/usr/local/airflow/code/dsm_demand_idap_na_caps_product.sql'
sf_sql_load_idap_product = SnowFlakeOperator(
        task_id='load_caps_product_snowflake',
        provide_context=True,
        conn_id = snowflake_conn,
        sql_file = s3_sql_dir,
	    parameters={'ROLE_NAME': idap_role,'WAREHOUSE_NAME': idap_wh,'DB_NAME': idap_db,'STG_SCHEMA_NAME': idap_stg_schema,'TGT_SCHEMA_NAME': idap_target_schema, 'CAPS_PRODUCT_STG': sf_input_s3_folder, 'FILE_FORMAT': sf_file_format_name},
	dag=dag)

# Executing email notify
# -------------------------------------------------------
emailNotify = EmailOperator( task_id='product_job_schedule_finished_daily',
                             to = idap_email,
                             subject = 'IDAP_NA_CAPS_PRODUCT_DAILY_LOAD completed successfully',
                             html_content = "<p>Hi,</p><p>IDAP_NA_CAPS_PRODUCT_DAILY_LOAD completed successfully in {env}.</p><p>Thanks,</p><p>DDS Team.</p>".format(env = env),
                             dag=dag)

slack_message_success = SlackOperator(
    task_id='slack_notification_success',
    channel=slack_channel,
    depends_on_past=False,
    wait_for_downstream=False,
    message= '{dag_name} has been successfully completed.'.format(dag_name = dag_name),
    dag=dag)


start>>sf_sql_load_idap_product>>emailNotify>>slack_message_success>>success
