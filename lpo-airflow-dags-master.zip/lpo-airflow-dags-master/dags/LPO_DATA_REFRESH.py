#========================================================================================================
# Script Name : LPO_GC_SAS_DAILY_JOB
#========================================================================================================

import pprint
import datetime
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.models import DAG
from airflow.models import Variable
from airflow.operators.email_operator import EmailOperator
from airflow.operators import SlackOperator
from airflow.operators.dummy_operator import DummyOperator

pp = pprint.PrettyPrinter(indent=4)

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_DATA_REFRESH'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
schedule_interval = None
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'
lpo_pager_duty = Variable.get("lpo_pager_duty")
lpo_data_refresh_target = Variable.get("lpo_data_refresh_target")
lpo_data_refresh_location = Variable.get("lpo_data_refresh_location")

default_queue = 'airflow'
# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2020, 5, 31),
    'email': lpo_email,
    'email_on_failure': lpo_email_on_failure,
    'email_on_retry': False,
    #'retries': 0,
    #'retry_delay': timedelta(minutes=30),
    'catchup': False
}

dag = DAG('LPO_DATA_REFRESH', default_args=default_args, schedule_interval=None, concurrency=1,
          max_active_runs=1)

############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='SAS DATA Refresh to lower Env is failed.').execute(context)


Start_Task = DummyOperator(
    task_id='start',
    queue=default_queue,
    catch_up=True,
    retries=1,
    dag=dag)

getmaxdate_and_update_in_target = SSHOperator(task_id='getmaxdate_and_update_in_target',
                                          ssh_conn_id='lpo_Prog',
                                          command='/usr/bin/ksh /home/a.etlusr/getmaxdate.sh {lpo_data_refresh_target} {lpo_data_refresh_location} '.format(lpo_data_refresh_target=lpo_data_refresh_target,lpo_data_refresh_location=lpo_data_refresh_location),
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

Data_refresh = SSHOperator(task_id='Data_refresh',
                                      ssh_conn_id='lpo_Prog',
                                      command='/usr/bin/ksh /home/a.etlusr/backupdata.sh {lpo_data_refresh_target} {lpo_data_refresh_location} '.format(lpo_data_refresh_target=lpo_data_refresh_target,lpo_data_refresh_location=lpo_data_refresh_location),
                                      trigger_rule='all_success',
                                      on_failure_callback=failurecallback,
                                      dag=dag)


############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='SAS DATA Refresh is completed successfully.',
    dag=dag)



############################
# Email Notification
############################
email_notify = EmailOperator(
    task_id='job_status_email_notification',
    to=lpo_email,
    subject='DAG LPO_DATA_REFRESH',
    html_content="<p>Hi,</p><p>SAS DATA Refresh is completed successfully.</p><p>Thanks,</p><p>LPO Team.</p>",
    dag=dag)

End_task = DummyOperator(
    task_id='success',
    queue=default_queue,
    retries=1,
    dag=dag)

Start_Task.set_downstream(getmaxdate_and_update_in_target)
getmaxdate_and_update_in_target.set_downstream(Data_refresh)
Data_refresh.set_downstream(slack_alerts)
slack_alerts.set_downstream(email_notify)
email_notify.set_downstream(End_task)
