from datetime import datetime, timedelta
import json

from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmrOperator, \
    SparkOperator, SlackOperator, \
    BatchEndOperator, PythonOperator, GenieHiveOperator
from airflow.operators.dummy_operator import DummyOperator

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_LOCATION_JOB'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
start_date = datetime(2020, 3, 3, 10, 0, 0)
schedule_interval = '30 19 * * *'
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
env = Variable.get("lpo_env")
cluster_name = env + '-lpo-location-delta-ingest'
bucket = Variable.get("ngap_s3_bucket")
lpo_bucket = Variable.get("dsmdemand_s3_bucket")
ngap_bucket = Variable.get("ngap_stg_bucket")
RDF_DB = Variable.get("rdf_db")
LPO_DB = Variable.get("lpo_db")
STG_LPO_DB = Variable.get("stg_lpo_db")
lpo_role_arn = Variable.get("lpo_role_arn")
on_failure_cb = EmrOperator(owner='no-owner', task_id='no-task', cluster_action='terminate', cluster_name=cluster_name).execute
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'
lpo_pager_duty = Variable.get("lpo_pager_duty")


# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': start_date,
    'email': [lpo_email, lpo_pager_duty],
    'email_on_failure': lpo_email_on_failure,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=10)
}

dag = DAG('LPO_LOCATION_JOB', default_args=default_args, schedule_interval=schedule_interval, concurrency=1,
          max_active_runs=1)

default_queue = 'airflow'

############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='Location daily file extract job has failed.').execute(context)



def get_epoch_time(**kwargs):
    now = datetime.now()
    runtime = now.strftime("%Y%m%d%H%M%S")
    kwargs['ti'].xcom_push(key='runtime', value=runtime)


RUN_DT = """{{ ds }}"""

RUNTIME = """{{ ti.xcom_pull(key="runtime",task_ids="xcom") }}"""

lpo_location_src_path = 's3://dsmdemand117f359-prd-us-east-1/data/application/location/snapshots/stg_location/GC/date='+RUN_DT+'/'

start = DummyOperator(
    task_id='location_delta_process',
    queue=default_queue,
    retries=5,
    retry_delay=timedelta(seconds=15),
    dag=dag)


task_emr_spinup = EmrOperator(
    task_id='emr_spinup',
    cluster_action='spinup',
    cluster_name=cluster_name,
    num_core_nodes=12,
    num_task_nodes=8,
    queue=default_queue,
    classification='bronze',
    core_inst_type='r5d.4xlarge',
    task_inst_type='r5d.4xlarge',
    project_id='FY160072.02-LPO',
    emr_version='5.29.0',
    bootstrap_actions=[
        {
            'Name': 'EMR Bootstrap Install Pandas and BOTO3',
            'ScriptBootstrapAction': {
                'Path': 's3://{0}/{1}/dstiengineering-lpo/airflow_deploy/scripts/pandasboto3install.sh'.format(bucket, env),
                'Args': []
            }
        }
    ],
    retries=5,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_python = PythonOperator(
    task_id='xcom',
    queue=default_queue,
    provide_context=True,
    python_callable=get_epoch_time,
    on_failure_callback=failurecallback,
    dag=dag
)

staging_dict = {
    "src_path": lpo_location_src_path,
    "dest_path": "s3://" + ngap_bucket + "/dstiengineering/lpo/" + env + "/location_stg/gc/date=" + RUN_DT + "/",
    "search_pattern": "STG_LOCATION_20"
}

lpo_location_staging_cmd = ' --conf spark.yarn.executor.extraClassPath=./ --conf spark.dynamicAllocation.enabled=false' \
                           ' --conf fs.s3n.multipart.uploads.enabled=true' \
                           ' s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/python/lpo_staging_service.py "' + json.dumps(staging_dict) + '"'

lpo_location_staging_task = SparkOperator(
    task_id='location_staging',
    command=lpo_location_staging_cmd,
    job_name="location_staging",
    queue=default_queue,
    sched_type=cluster_name,
    on_failure_callback=failurecallback,
    dag=dag)

lpo_location_stage_to_raw_cmd = '-f s3://'+bucket+'/'+env+'/dstiengineering-lpo/emr-scripts/hive/location_stg_raw.hql -hivevar RAW_DATABASE='+LPO_DB+' -hivevar STG_LOCATION=s3://'+ngap_bucket+'/dstiengineering/lpo/'+env+'/location_stg/gc/date='+RUN_DT+'/ -hivevar TABLE_FROM=location_gc'

lpo_location_stage_to_raw = GenieHiveOperator(
    task_id='location_stage_to_raw',
    command=lpo_location_stage_to_raw_cmd,
    on_failure_callback=failurecallback,
    job_name='location_stage_to_raw',
    sched_type=cluster_name,
    queue=default_queue,
    dag=dag)


task_emr_terminate = EmrOperator(
    task_id='emr_terminate',
    cluster_action='terminate',
    cluster_name=cluster_name,
    queue=default_queue,
    dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='Location daily job has successfully completed.',
    dag=dag)

end = BatchEndOperator(
    queue=default_queue,
    dag=dag)


start.set_downstream(task_emr_spinup)

task_emr_spinup.set_downstream(task_python)
task_python.set_downstream(lpo_location_staging_task)

lpo_location_staging_task.set_downstream(lpo_location_stage_to_raw)
lpo_location_stage_to_raw.set_downstream(task_emr_terminate)
task_emr_terminate.set_downstream(slack_alerts)
slack_alerts.set_downstream(end)
start.set_downstream(end)
