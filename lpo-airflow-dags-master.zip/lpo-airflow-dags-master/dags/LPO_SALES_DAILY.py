from datetime import datetime, timedelta
import json

from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmrOperator, \
    SparkOperator, SlackOperator, \
    BatchEndOperator, PythonOperator, GenieHiveOperator
from airflow.operators.dummy_operator import DummyOperator

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SALES_DAILY_JOB'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
start_date = datetime(2019, 1, 19, 10, 0, 0)
schedule_interval = '0 18 * * *'
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
airflow_args = Variable.get("lpo_sales_dict", deserialize_json=True)
env = Variable.get("lpo_env")
cluster_name = env + '-lpo-sales-delta-process'
bucket = Variable.get("ngap_s3_bucket")
lpo_bucket = Variable.get("dsmdemand_s3_bucket")
ngap_bucket = Variable.get("ngap_stg_bucket")
RDF_DB = Variable.get("rdf_db")
LPO_DB = Variable.get("lpo_db")
lpo_role_arn = Variable.get("lpo_role_arn")
on_failure_cb = EmrOperator(owner='no-owner', task_id='no-task', cluster_action='terminate', cluster_name=cluster_name).execute


# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': start_date,
    'email': lpo_email,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=30)
}

dag = DAG('LPO_SALES_DAILY_JOB', default_args=default_args, schedule_interval=schedule_interval, concurrency=1,
          max_active_runs=1)

default_queue = 'airflow'

############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='sales daily job has failed.').execute(context)


def get_epoch_time(**kwargs):
    now = datetime.now()
    runtime = now.strftime("%Y%m%d%H%M%S")
    kwargs['ti'].xcom_push(key='runtime', value=runtime)


RUN_DT = """{{ ds }}"""

RUNTIME = """{{ ti.xcom_pull(key="runtime",task_ids="xcom") }}"""


start = DummyOperator(
    task_id='sales_delta_process',
    queue=default_queue,
    dag=dag)


task_emr_spinup = EmrOperator(
    task_id='emr_spinup',
    cluster_action='spinup',
    cluster_name=cluster_name,
    num_core_nodes=12,
    num_task_nodes=8,
    queue=default_queue,
    classification='bronze',
    core_inst_type='r3.2xlarge',
    task_inst_type='r3.2xlarge',
    project_id='FY160072.02-LPO',
    emr_version='5.9.0',
    bootstrap_actions=[
        {
            'Name': 'EMR Bootstrap Install Pandas and BOTO3',
            'ScriptBootstrapAction': {
                'Path': 's3://{0}/{1}/dstiengineering-lpo/airflow_deploy/scripts/pandasboto3install.sh'.format(bucket, env),
                'Args': []
            }
        }
    ],
    retries=5,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_python = PythonOperator(
    task_id='xcom',
    queue=default_queue,
    provide_context=True,
    python_callable=get_epoch_time,
    on_failure_callback=failurecallback,
    dag=dag
)

sales_process_dict = {
    "sales_stg_path": "s3://" + ngap_bucket + "/dstiengineering/lpo/" + env + "/sales/stage/",
    "sales_target_path": "s3://" + ngap_bucket + "/dstiengineering/lpo/" + env + "/sales/",
    "lpo_target_path": "s3://" + lpo_bucket + "/data/application/sales_fact/gc/",
    "sales_table": RDF_DB + ".global_dtc_daily_demand",
    "location_table": LPO_DB + ".location_gc",
    "product_table": LPO_DB + ".product",
    "config_file": "sales_load.prop",
    "airflow_args": airflow_args,
    "processing_region": "default_region",
    "run_date": RUN_DT,
    "output_file_prefix": "stg_sales_fact",
    "role_arn": lpo_role_arn,
    "coalesce_val": "1"
}

sales_process_spark_cmd = '--executor-memory 15G --driver-memory 12G --executor-cores 5 --num-executors 10 ' \
                          ' --conf spark.yarn.executor.extraClassPath=./ --conf fs.s3n.multipart.uploads.enabled=true ' \
                          ' --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 ' \
                          ' --files s3://' + bucket + '/' + env + '/dstiengineering-lpo/prop/sales_load.prop ' \
                          ' --py-files s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/python/utilities.py ' \
                          ' s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/spark/sales_daily_load.py "' + json.dumps(sales_process_dict) + '"'


sales_load_processing = SparkOperator(
    task_id='sales_load_processing',
    command=sales_process_spark_cmd,
    job_name="sales_load_processing",
    queue=default_queue,
    sched_type=cluster_name,
    on_failure_callback=failurecallback,
    dag=dag)

task_emr_terminate = EmrOperator(
    task_id='emr_terminate',
    cluster_action='terminate',
    cluster_name=cluster_name,
    queue=default_queue,
    dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='sales daily job has successfully completed.',
    dag=dag)

end = BatchEndOperator(
    queue=default_queue,
    dag=dag)



start.set_downstream(task_emr_spinup)
task_emr_spinup.set_downstream(task_python)
task_python.set_downstream(sales_load_processing)

sales_load_processing.set_downstream(task_emr_terminate)

task_emr_terminate.set_downstream(slack_alerts)
slack_alerts.set_downstream(end)
start.set_downstream(end)