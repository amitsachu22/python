#========================================================================================================
# Script Name : IDAP_PRODUCT_ATTRIBUTES_NDF_TO_MERCH7
#
# Purpose: It exports product attributes from NDF to S3 and later gets added to Merch 7 file for SAS
#
# Created By: Raj Reddy
# Date: 03-01-2019
# URL to Version One story for this effort
# https://www10.v1host.com/NIKE01a/story.mvc/Summary?oidToken=Story%3A2654215&RoomContext=TeamRoom%3A2655535
#========================================================================================================

# --- Imports
# -----------------------------------------------------------------------

import pprint
from airflow import DAG, settings
from airflow.operators import EmailOperator, DummyOperator, SnowFlakeOperator, SlackOperator, BatchStartOperator, BatchEndOperator
from datetime import datetime, timedelta
from airflow.models import Variable, DAG, DagRun
from boto.s3.key import Key
from airflow.utils.state import State

pp = pprint.PrettyPrinter(indent=4)  

# DAG Specific parameters and variables
#-----------------------------------------------------------------------
dag_name = 'IDAP_PRODUCT_ATTRIBUTES_NDF_TO_MERCH7'
dag_concurrency = 1    # how many tasks max per DAG
dag_max_active_runs = 1    # concurrently how many instances can run of the DAG
dag_concurrency_pool = ''    # Add in Airflow > Admin > Pools
schedule_interval = '0 19 * * 6'    #12 Noon PST every Saturday
success_message_html = "<p>Hi,</p><p>Product Attributes job from NDF to S3 completed successfully.</p><p>Thanks,</p><p>DDS Team.</p>" #
main_reporting_email = Variable.get("sas_failure_email")
cc_reporting_email = '' 
slack_channel = Variable.get("idap_alerts_slack_channel")

#Airflow variables
#-----------------------------------------------------------------------
bucket = Variable.get("ngap_s3_bucket")
pes_db = Variable.get("pes_sf_db")
idap_role = Variable.get("idap_sf_role_prod")
idap_wh = Variable.get("idap_sf_wh")
idap_db = Variable.get("idap_sf_db")
env = Variable.get("env")

#Snowflake variables
#-----------------------------------------------------------------------
snowflake_conn = 'snowflake_idap'
idap_view_schema = 'IDAP_ETL_V'
pes_view_schema = 'PROCESSED'
sf_file_format_name = 'IDAP_ETL_V_PIPE_DELIMITED_FILE'
sf_file_name = 'IDAP_NA/PRODUCT/MMX_PRODUCT_MASTER.csv.gz'
sf_output_s3_folder = 'DSMIDAP_IDAP_ETL_V'
default_queue = 'airflow'

# Airflow default DAG parameters
# -------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2020, 3, 3, 18, 0, 0),
    'email': [ main_reporting_email ],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=5)

}

dag = DAG(dag_name, 
    default_args=default_args, 
    schedule_interval= schedule_interval,
    concurrency=dag_concurrency,
    max_active_runs=dag_max_active_runs)


############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='Product Attributes NDF to Merch7 export has failed.').execute(context)

# Just for UI - Does nothing
# -------------------------------------------------------
Start_Task = DummyOperator(task_id='Start_Task', dag=dag)

# SQL file will upload Product Attributes from NDF to S3 for Merch7 as a csv file.
# we are connectiing to PES_ARIA_PRODUCT_PROD database, schema PROCESSED, and to MMX_LINE_PLAN_ALL_V view to get the product attributes
s3_sql_dir2 = '/usr/local/airflow/code/idap_product_attributes_from_ndf_to_s3.sql'
sf_sql_upload = SnowFlakeOperator(
        task_id='PRODUCT_ATTRIBUTES_FROM_NDF_TO_S3',
        provide_context=True,
        conn_id = snowflake_conn,
        sql_file = s3_sql_dir2,
        parameters={'ROLE_NAME_IDAP': idap_role,
					'WH_NAME_IDAP': idap_wh,
					'DB_NAME_IDAP': idap_db,
					'SCHEMA_NAME_IDAP_V': idap_view_schema,
					'S3_OUTPUT_FOLDER': sf_output_s3_folder,
					'FILE_NAME': sf_file_name,
					'DB_NAME_PES': pes_db,
					'SCHEMA_NAME_PES': pes_view_schema,
					'IDAP_ETL_V_PIPE_DELIMITED_FORMAT': sf_file_format_name
                    },
        on_failure_callback=failurecallback,
         dag=dag)

# Executing Slack Messages
# -------------------------------------------------------
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    depends_on_past=False,
    wait_for_downstream=False,
    message= '{dag_name} has been successfully completed.'.format(dag_name = dag_name),
    dag=dag)

# Executing Email Notification
# -------------------------------------------------------
emailNotify = EmailOperator(
   task_id='email_update',
   to = main_reporting_email,
   cc= cc_reporting_email,
   subject = '{dag_name} completed successfully in {env}'.format(dag_name = dag_name, env = env),
   html_content = success_message_html,
   dag=dag
)


#Just for UI - Does nothing
#-------------------------------------------------------

End_task = DummyOperator(task_id='End_Task', dag=dag)

Start_Task>>sf_sql_upload>>slack_alerts>>emailNotify>>End_task
