#========================================================================================================
# Script Name : LPO_GC_SAS_AD_HOC_JOB
#========================================================================================================

import datetime
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.models import DAG
from airflow.models import Variable
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.email_operator import EmailOperator
from airflow.operators import SlackOperator



# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SAS_AD_HOC_JOB'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
schedule_interval = None
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")


# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2020, 5, 31),
    'email': lpo_email,
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': datetime.timedelta(minutes=30),
    'catchup': False
}

dag = DAG('LPO_SAS_AD_HOC_DATA_LOAD_JOB', default_args=default_args, schedule_interval=None, concurrency=1,
          max_active_runs=1)


############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='sas ad hoc job has failed.').execute(context)


source_file_transfer = SSHOperator(task_id='source_file_transfer_ad_hoc',
                                          ssh_conn_id='lpo_Prog',
                                          command="/opt/sas/fes/LoadMgr/util/lpo_transfer.sh download ",
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

# unzip_gc_etl_files = SSHOperator(task_id='unzip_gc_etl_files_ad_hoc',
#                                         ssh_conn_id='lpo_Prog',
#                                         command="/opt/sas/fes/LoadMgr/util/unzip_src_files.sh ",
#                                         trigger_rule='all_success',
#                                         on_failure_callback=failurecallback,
#                                         dag=dag)

gc_source_to_sas_stg = SSHOperator(task_id='gc_source_to_sas_stg_ad_hoc',
                                          ssh_conn_id='lpo_Prog',
                                          command="/opt/sas/fes/LoadMgr/bin/controller.sh ad_hoc_src2stg ",
                                          trigger_rule='all_success',
                                          on_failure_callback=failurecallback,
                                          dag=dag)

gc_stg_data_mart = SSHOperator(task_id='gc_stg_data_mart_ad_hoc',
                                      ssh_conn_id='lpo_Prog',
                                      command="/opt/sas/fes/LoadMgr/bin/controller.sh ad_hoc_stg2dm ",
                                      trigger_rule='all_success',
                                      on_failure_callback=failurecallback,
                                      dag=dag)

gc_lpo = SSHOperator(task_id='gc_lpo_ad_hoc',
                            ssh_conn_id='lpo_Prog',
                            command="/opt/sas/fes/LoadMgr/util/process_lpo_partition.sh ",
                            trigger_rule='all_success',
                            on_failure_callback=failurecallback,
                            dag=dag)

export_and_transfer = SSHOperator(task_id='export_and_transfer_ad_hoc',
                                         ssh_conn_id='lpo_Prog',
                                         command="/opt/sas/fes/LoadMgr/util/lpo_transfer.sh upload ",
                                         trigger_rule='all_success',
                                         on_failure_callback=failurecallback,
                                         dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='sas ad hoc job has successfully completed.',
    dag=dag)


############################
# Email Notification
############################
email_notify = EmailOperator(
    task_id='job_status_email_notification',
    to=lpo_email,
    subject='DAG SAS_ad_hoc_JOB',
    html_content="<p>Hi,</p><p>Job is completed successfully.</p><p>Thanks,</p><p>LPO Team.</p>",
    dag=dag)

All_done = DummyOperator(
    task_id='finished_ad_hoc_data_load',
    trigger_rule='all_success',
    dag=dag)


source_file_transfer.set_downstream(gc_source_to_sas_stg)
#unzip_gc_etl_files.set_downstream(gc_source_to_sas_stg)
gc_source_to_sas_stg.set_downstream(gc_stg_data_mart)
gc_stg_data_mart.set_downstream(gc_lpo)
gc_lpo.set_downstream(export_and_transfer)
export_and_transfer.set_downstream(slack_alerts)
slack_alerts.set_downstream(email_notify)
email_notify.set_downstream(All_done)
