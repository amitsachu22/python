from datetime import datetime, timedelta
import json

from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmrOperator, \
    SparkOperator, SlackOperator, \
    BatchEndOperator, PythonOperator, GenieHiveOperator
from airflow.operators.dummy_operator import DummyOperator

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_PRODUCT_JOB'
dag_concurrency = 2  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
start_date = datetime(2019, 1, 19, 10, 0, 0)
schedule_interval = '0 17 * * *'
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
env = Variable.get("lpo_env")
cluster_name = env + '-lpo-product-delta-ingest'
bucket = Variable.get("ngap_s3_bucket")
lpo_bucket = Variable.get("dsmdemand_s3_bucket")
ngap_bucket = Variable.get("ngap_stg_bucket")
RDF_DB = Variable.get("rdf_db")
LPO_DB = Variable.get("lpo_db")
lpo_role_arn = Variable.get("lpo_role_arn")
on_failure_cb = EmrOperator(owner='no-owner', task_id='no-task', cluster_action='terminate', cluster_name=cluster_name).execute


# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': start_date,
    'email': lpo_email,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=30)
}

dag = DAG('LPO_PRODUCT_JOB', default_args=default_args, schedule_interval=schedule_interval, concurrency=1,
          max_active_runs=1)

default_queue = 'airflow'

############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='Product file extract job has failed.').execute(context)



def get_epoch_time(**kwargs):
    now = datetime.now()
    runtime = now.strftime("%Y%m%d%H%M%S")
    kwargs['ti'].xcom_push(key='runtime', value=runtime)


RUN_DT = """{{ ds }}"""

RUNTIME = """{{ ti.xcom_pull(key="runtime",task_ids="xcom") }}"""

lpo_product_src_path = 's3://dsmdemand117f359-prd-us-east-1/data/application/catalogdeltaspublisher/snapshots/raw/date='+RUN_DT+'/'


start = DummyOperator(
    task_id='product_delta_process',
    queue=default_queue,
    dag=dag)


task_emr_spinup = EmrOperator(
    task_id='emr_spinup',
    cluster_action='spinup',
    cluster_name=cluster_name,
    num_core_nodes=12,
    num_task_nodes=8,
    queue=default_queue,
    classification='bronze',
    core_inst_type='r3.2xlarge',
    task_inst_type='r3.2xlarge',
    project_id='FY160072.02-LPO',
    emr_version='5.9.0',
    bootstrap_actions=[
        {
            'Name': 'EMR Bootstrap Install Pandas and BOTO3',
            'ScriptBootstrapAction': {
                'Path': 's3://{0}/{1}/dstiengineering-lpo/airflow_deploy/scripts/pandasboto3install.sh'.format(bucket, env),
                'Args': []
            }
        }
    ],
    retries=5,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_python = PythonOperator(
    task_id='xcom',
    queue=default_queue,
    provide_context=True,
    python_callable=get_epoch_time,
    on_failure_callback=failurecallback,
    dag=dag
)

staging_dict = {
    "src_path": lpo_product_src_path,
    "dest_path": "s3://" + ngap_bucket + "/dstiengineering/lpo/" + env + "/product/raw/date=" + RUN_DT + "/",
    "search_pattern": "rawproductdelta-20"
}

lpo_product_staging_cmd = ' --conf spark.yarn.executor.extraClassPath=./ --conf spark.dynamicAllocation.enabled=false' \
                          '  --conf fs.s3n.multipart.uploads.enabled=true' \
                          '  s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/python/lpo_staging_service.py "' + json.dumps(staging_dict) + '"'

lpo_product_staging_task = SparkOperator(
    task_id='product_staging',
    command=lpo_product_staging_cmd,
    job_name='product_staging',
    queue=default_queue,
    sched_type=cluster_name,
    on_failure_callback=failurecallback,
    dag=dag)

derive_dict = {
    "input_path": "s3://" + ngap_bucket + "/dstiengineering/lpo/" + env + "/product/raw/date=" + RUN_DT + "/",
    "target_path": "s3://" + ngap_bucket + "/dstiengineering/lpo/" + env + "/product/derived/",
    "product_db": LPO_DB,
    "product_table":"product",
    "run_dt": RUN_DT
}

lpo_product_derive_cmd = ' --executor-memory 10G --driver-memory 12G --executor-cores 5 --num-executors 6' \
                         ' --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2' \
                         ' s3://' + bucket + '/' + env + '/dstiengineering-lpo/emr-scripts/spark/product_daily_load.py "' + json.dumps(derive_dict) + '"'


lpo_derive_product_task = SparkOperator(
    task_id='product_derive',
    command=lpo_product_derive_cmd,
    job_name='product_derive',
    queue=default_queue,
    sched_type=cluster_name,
    on_failure_callback=failurecallback,
    dag=dag)



task_emr_terminate = EmrOperator(
    task_id='emr_terminate',
    cluster_action='terminate',
    cluster_name=cluster_name,
    queue=default_queue,
    dag=dag)

############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='product daily job has successfully completed.',
    dag=dag)

end = BatchEndOperator(
    queue=default_queue,
    dag=dag)


start.set_downstream(task_emr_spinup)

task_emr_spinup.set_downstream(task_python)
task_python.set_downstream(lpo_product_staging_task)

lpo_product_staging_task.set_downstream(lpo_derive_product_task)
lpo_derive_product_task.set_downstream(task_emr_terminate)
task_emr_terminate.set_downstream(slack_alerts)
slack_alerts.set_downstream(end)
start.set_downstream(end)
