#========================================================================================================
# Script Name : LPO_SAS_MONDAY_DOWNLOAD
#========================================================================================================

import pprint

import datetime
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.models import DAG
from airflow.models import Variable
from airflow.operators import EmailOperator, TriggerDagRunOperator, SlackOperator 
from airflow.operators.dummy_operator import DummyOperator

pp = pprint.PrettyPrinter(indent=4)

# DAG Specific parameters and variables
# -----------------------------------------------------------------------
dag_name = 'LPO_SAS_MONDAY_DOWNLOAD'
dag_concurrency = 1  # how many tasks max per DAG
dag_max_active_runs = 1  # concurrently how many instances can run of the DAG
schedule_interval = None
lpo_email = Variable.get("lpo_sas_status_mail")
slack_channel = Variable.get("lpo_slack_alerts")
s3_Connection = 's3_Conn_lpo'
lpo_email_on_failure = Variable.get("lpo_email_on_failure") == 'True'
lpo_pager_duty = Variable.get("lpo_pager_duty")
# Airflow default DAG parameters
# -------------------------------------------------------------------------
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2020, 5, 31),
    'email': [lpo_email, lpo_pager_duty],
    'email_on_failure': lpo_email_on_failure,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': datetime.timedelta(minutes=30),
    'catchup': False
}


dag = DAG('LPO_SAS_MONDAY_DOWNLOAD', default_args=default_args, schedule_interval=None, concurrency=1, max_active_runs=1)


default_queue = 'airflow'

############################
# On failure function
############################
def failurecallback(context):
    SlackOperator(owner='owner', task_id='task_id', channel=slack_channel,
                  message='LPO_SAS_MONDAY_DOWNLOAD job has failed.').execute(context)


Start_Task = DummyOperator(
    task_id='start',
    queue=default_queue,
    catch_up=True,
    retries=1,
    dag=dag)


Transfer_source_files_for_GC_from_S3 = SSHOperator(task_id='Transfer_source_files_for_GC_from_S3',
                                          ssh_conn_id='lpo_Prog',
                                         command="/usr/bin/ksh /opt/sas/fes/LoadMgr/util/lpo_transfer.sh download ",
                                         trigger_rule='all_success',
                                         on_failure_callback=failurecallback,
                                         dag=dag)



############################
# Slack  messages
############################
slack_alerts = SlackOperator(
    task_id='send_slack',
    channel=slack_channel,
    trigger_rule='all_success',
    message='LPO SAS MONDAY JOB has been successfully completed.',
    dag=dag)


############################
# Email Notification
############################
email_notify = EmailOperator(
    task_id='job_status_email_notification',
    to=lpo_email,
    subject='DAG LPO_SAS_Monday_Download_JOB',
    html_content="<p>Hi,</p><p>LPO_SAS_Monday_Download_JOB is completed successfully.</p><p>Thanks,</p><p>LPO Team.</p>",
    dag=dag)

All_done = DummyOperator(
    task_id='finished_LPO_SAS_Monday_Download_JOB',
    trigger_rule='all_success',
    dag=dag)


Start_Task.set_downstream(Transfer_source_files_for_GC_from_S3)
Transfer_source_files_for_GC_from_S3.set_downstream(slack_alerts)
slack_alerts.set_downstream(email_notify)
email_notify.set_downstream(All_done)
