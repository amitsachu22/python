
/*
#===================================================================================================
# Script Name : dds_na_caps_product.sql
# Purpose     : This Script is used to Load Product Data from S3 to the below tables in SnowFlake.

Date           Name                Comments
03/10/2019    jgali3	           Added Load_DATE in staging table
#===================================================================================================
*/

ALTER SESSION SET TIMESTAMP_TYPE_MAPPING = TIMESTAMP_NTZ;
ALTER SESSION SET TIMEZONE = 'America/Los_Angeles';


/*---Parameters  comes from Airflow snowflake operator ---*/


USE ROLE $ROLE_NAME;
USE WAREHOUSE $WAREHOUSE_NAME;
USE DATABASE $DB_NAME;
USE SCHEMA $STG_SCHEMA_NAME;


TRUNCATE TABLE $STG_SCHEMA_NAME.CAPS_PRODUCT_STG;

-- Copy Data from S3 file to staging table
 copy into $STG_SCHEMA_NAME.CAPS_PRODUCT_STG
(
   ID
  ,PARENT_ID
  ,STYLE
  ,COLOR
  ,SIZE
  ,CATEGORY
  ,DIVISION
  ,GENDERAGE
  ,CLASS
  ,GTIN
  ,GTIN_START_DATE
  ,GTIN_END_DATE
  ,WHOLESALE_COST_USD
  ,MSRP_USD
  ,IS_NIKE
  ,SOLD_IN_US
  ,LIFECYCLE
  ,LOAD_DATE
 
)
from (
  
SELECT  
      t.$1              AS ID
    , t.$2              AS PARENT_ID
    , t.$3              AS STYLE
    , t.$4              AS COLOR
    , t.$5              AS SIZE
    , t.$6              AS CATEGORY
    , t.$7              AS DIVISION
    , t.$8              AS GENDERAGE
    , t.$9              AS CLASS
    , t.$10             AS GTIN
    , t.$11             AS GTIN_START_DATE
    , t.$12             AS GTIN_END_DATE
    , t.$13             AS WHOLESALE_COST_USD
    , t.$14             AS MSRP_USD
    , t.$15             AS IS_NIKE
    , t.$16             AS SOLD_IN_US
    , t.$17             AS LIFECYCLE
    ,current_timestamp(2)AS  LOAD_DATE      
    from @$DSMDEMAND/data/application/catalog-export/delivery/ITEM_MAPPING.csv.gz t)
  file_format = (format_name = $FILE_FORMAT)
  on_error = 'skip_file' FORCE = TRUE;
 

truncate TABLE $TGT_SCHEMA_NAME.CAPS_PRODUCT;

-- Load data from staging table
INSERT INTO $TGT_SCHEMA_NAME.CAPS_PRODUCT(
	ID  ,
	PARENT_ID ,
	STYLE ,
	COLOR ,
	STYLE_COLOR,
	SIZE ,
	CATEGORY ,
	DIVISION ,
	GENDERAGE ,
	CLASS ,
	GTIN ,
	GTIN_START_DATE,
	GTIN_END_DATE,
	WHOLESALE_COST_USD,
	MSRP_USD,
	IS_NIKE,
	SOLD_IN_US,
	LIFECYCLE ,
	LOAD_DATE
)
SELECT DISTINCT
	ID,
	PARENT_ID,
	STYLE,
	COLOR,
	CONCAT(STYLE,CONCAT('-', COLOR)),
	SIZE,
	CATEGORY,
	DIVISION,
	GENDERAGE,
	CLASS,
	GTIN,
	to_date(decode(GTIN_START_DATE,'null',NULL,GTIN_START_DATE)),
	to_date(decode(GTIN_END_DATE,NULL,'9999-12-31',GTIN_END_DATE)),
	WHOLESALE_COST_USD,
	MSRP_USD,
	IS_NIKE,
	SOLD_IN_US,
	LIFECYCLE,
	LOAD_DATE
from $STG_SCHEMA_NAME.CAPS_PRODUCT_STG;
