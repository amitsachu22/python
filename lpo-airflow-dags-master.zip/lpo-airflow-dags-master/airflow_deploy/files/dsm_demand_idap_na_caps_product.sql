/*
#===================================================================================================
# Script Name : dsm_demand_na_caps_product.sql
# Purpose     : This Script is used to Load Peroduct Data to the below tables in SnowFlake.
# 12/28/2018  :updated the item_mapping.csv location from archive to delivery directory (jgali3)
#===================================================================================================
*/

ALTER SESSION SET TIMESTAMP_TYPE_MAPPING = TIMESTAMP_NTZ;
ALTER SESSION SET TIMEZONE = 'America/Los_Angeles';

/*---Parameters  comes from Airflow snowflake operator ---*/

USE ROLE $ROLE_NAME;
USE WAREHOUSE $WAREHOUSE_NAME;
USE DATABASE $DB_NAME;
USE SCHEMA $STG_SCHEMA_NAME;


 -- Clear Staging table
 DELETE FROM $DB_NAME.$STG_SCHEMA_NAME.CAPS_PRODUCT_STG;
 --Copy Data From S3 INTO staging table
 copy into $DB_NAME.$STG_SCHEMA_NAME.CAPS_PRODUCT_STG
  from @$CAPS_PRODUCT_STG/data/application/catalog-export/delivery/ITEM_MAPPING.csv.gz
  file_format = (format_name = $FILE_FORMAT)
  on_error = 'skip_file' FORCE = TRUE;
  
  
  


-- Clear Target table
truncate $TGT_SCHEMA_NAME.CAPS_PRODUCT_T;

-- Insert data from staging to target
INSERT INTO $DB_NAME.$TGT_SCHEMA_NAME.CAPS_PRODUCT_T(
	ID  ,
	PARENT_ID ,
	STYLE ,
	COLOR ,
	SIZE ,
	CATEGORY ,
	DIVISION ,
	GENDERAGE ,
	CLASS ,
	GTIN ,
	GTIN_START_DATE,
	GTIN_END_DATE,
	WHOLESALE_COST_USD,
	MSRP_USD,
	IS_NIKE,
	SOLD_IN_US,
	LIFECYCLE ,
	LOAD_DATE
)
SELECT DISTINCT
	ID,
	PARENT_ID,
	STYLE,
	COLOR,
	SIZE,
	CATEGORY,
	DIVISION,
	GENDERAGE,
	CLASS,
	GTIN,
	to_date(decode(GTIN_START_DATE,'null',NULL,GTIN_START_DATE)),
	to_date(decode(GTIN_END_DATE,NULL,'9999-12-31',GTIN_END_DATE)),
	WHOLESALE_COST_USD,
	MSRP_USD,
	IS_NIKE,
	SOLD_IN_US,
	LIFECYCLE,
	current_timestamp(2)
from $DB_NAME.$STG_SCHEMA_NAME.CAPS_PRODUCT_STG;
