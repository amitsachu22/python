/*
Object:  This sql script DDS_PRODUCT_ATTRIBUTES_NDF_TO_MERCH7 would generated the new additional PRODUCT seasonal attributes data in S3 bucket in the same existing PRODUCT location
Purpose: As part of the user story B-316723 Product - Add Attributes form NDF to Merch 7 file,
                                             this script is used to extract new attributes Product Tier and Product Size Scale, the seasonal attributes for the Product 
                                             Product Tier is enumerated by season 
Change log:

Created By: Vinod Gottepu/Mohan Gajula 02/26/2019
Updated By: Vinod Gottepu/Mohan Gajula 02/28/2019                 Modified script to remove size scale data enumerated and add Product Tier data enumerated
Updated By: Vinod Gottepu/Mohan Gajula 03/07/2019                 Modified script to add CPO_FRST_OFR_DT and remove Product Tier data enumerated, get Product Tier and Size Scale for the latest CPO_FRST_OFR_DT  date 
*/

USE ROLE $ROLE_NAME_IDAP;
USE WAREHOUSE $WH_NAME_IDAP;
USE DATABASE $DB_NAME_IDAP;
COPY INTO @$SCHEMA_NAME_IDAP_V.$S3_OUTPUT_FOLDER/$FILE_NAME FROM ( 
WITH CTE_1 AS
(
SELECT PROD_PROD_CD, CPO_FRST_OFR_DT, MO_SESN_YR_CD, STYL_SZ_SCALE_DESC, MO_PROD_TIER_DESC 
FROM $DB_NAME_PES.$SCHEMA_NAME_PES.MMX_LINE_PLAN_ALL_V 
WHERE GMO_GEO_NM = 'NORTH AMERICA' 
  AND CMO_CMO_STAT_IND = 'Active'
  AND CMO_CTRY_NM = 'UNITED STATES OF AMERICA'
  AND PROD_PROD_CD IS NOT NULL AND LENGTH(PROD_PROD_CD) > 7  
  AND FY_NBR >= 2017
), CTE_2 AS (
  SELECT PROD_PROD_CD, CPO_FRST_OFR_DT, STYL_SZ_SCALE_DESC, MO_PROD_TIER_DESC , RANK() OVER(PARTITION BY PROD_PROD_CD ORDER BY CPO_FRST_OFR_DT DESC) AS RNK
  FROM CTE_1
  ORDER BY PROD_PROD_CD, CPO_FRST_OFR_DT
), CTE_3 AS (
SELECT PROD_PROD_CD, STYL_SZ_SCALE_DESC, MO_PROD_TIER_DESC FROM CTE_2 WHERE RNK = 1
), CTE_4 AS (
SELECT PROD_PROD_CD, LISTAGG(CPO_FRST_OFR_DT, ', ') AS CPO_FRST_OFR_DT, LISTAGG(MO_SESN_YR_CD, ', ') AS MO_SESN_YR_CD
FROM CTE_1
GROUP BY PROD_PROD_CD 
)
SELECT a.PROD_PROD_CD AS PROD_PROD_CD, b.CPO_FRST_OFR_DT AS CPO_FRST_OFR_DT, b.MO_SESN_YR_CD AS MO_SESN_YR_CD, a.STYL_SZ_SCALE_DESC AS STYL_SZ_SCALE_DESC, a.MO_PROD_TIER_DESC AS MO_PROD_TIER_DESC
FROM CTE_3 a
JOIN CTE_4 b
  ON a.PROD_PROD_CD = b.PROD_PROD_CD
ORDER BY 1 
)
FILE_FORMAT = (FORMAT_NAME = $SCHEMA_NAME_IDAP_V.$IDAP_ETL_V_PIPE_DELIMITED_FORMAT)
HEADER = TRUE
SINGLE = TRUE
MAX_FILE_SIZE = 5368709120
OVERWRITE = TRUE 