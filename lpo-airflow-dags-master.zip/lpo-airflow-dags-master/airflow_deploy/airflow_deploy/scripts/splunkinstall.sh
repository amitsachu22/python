sudo pip install splunk_handler
