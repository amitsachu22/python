#!/usr/bin/env bash


sudo pip install pandas
sudo pip install xlrd
sudo pip install s3fs
sudo pip install boto3
sudo pip install requests --upgrade