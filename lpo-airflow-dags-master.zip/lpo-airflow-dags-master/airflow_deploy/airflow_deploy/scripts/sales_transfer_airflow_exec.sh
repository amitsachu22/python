#!/usr/bin/env bash

nike_emr_bin=$1
env=$2
python_dict=$3

echo "first argument: $1"
echo "second argument: $2"
echo "third argument: $3"

echo "Downloading the utilities python file to airflow worker node...."

aws s3 cp s3://${nike_emr_bin}/${env}/dstiengineering-lpo/emr-scripts/python/utilities.py /app/bin/dstiengineering-lpo/airflow_deploy/

echo "Started the sales cross account copy process python job....."

python /app/bin/dstiengineering-lpo/airflow_deploy/sales_cross_account_copy.py ${python_dict}

echo "Successfully completed the sales transfer to lpo aws account"