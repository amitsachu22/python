# ==================================================================================
#
# sales_cross_account_copy.py
#
# Description: This script is used to copy the sales file into LPO account by assuming LPO aws role.
#
# Parameters:
#
#               1. sales_cleaned_path (mandatory)
#               2. run_date (mandatory)
#               3. output_file_prefix (mandatory)
#
# ==================================================================================

"""
History
=============================================================================================================
 Date           Author                  Desc
-------------------------------------------------------------------------------------------------------------
 09-20-2018     Naveen Raj Kurapati     New Script created
============================================================================================================

Sample Command to run:

python sales_cross_account_copy.py '{"sales_target_path":"s3://nike-retail-stage/qa/lpo/rawdata/","lpo_target_path":"s3://dsmdemand117f359-non-us-east-1/data/application/sas/sales_fact/gc/","run_date":"2018-09-09","output_file_prefix":"stg_sales_fact","role_arn":"arn:aws:iam::069272765570:role/dsmdemand117f359-data-foundation-role"}'

"""


import logging
import json
import sys
import datetime as dt
import utilities as util


def copy_process(source_path, target_path, process_date, prefix, role_arn):

    run_dt_format = dt.datetime.strptime(process_date, '%Y-%m-%d')
    file_date = run_dt_format.strftime("%Y%m%d%H%M%S")

    cleaned_output_file_prefix = prefix + "_" + file_date
    rejected_output_file_prefix = prefix + "_" + "rejected_" + file_date

    rdf_cleaned_path = source_path + str(process_date) + "/sales_cleaned/"
    lpo_cleaned_path = target_path + "sales_cleaned/date=" + process_date + "/"
    rdf_rejected_path = source_path + str(process_date) + "/sales_rejected/"
    lpo_rejected_path = target_path + "sales_rejected/date=" + process_date + "/"

    logging.info("started cleaned sales files transfer from {0} to {1}".format(rdf_cleaned_path, lpo_cleaned_path))
    util.cross_account_file_copy(rdf_cleaned_path, lpo_cleaned_path, cleaned_output_file_prefix, role_arn)

    logging.info("started cleaned sales rejected files transfer from {0} to {1}".format(rdf_rejected_path, lpo_rejected_path))
    util.cross_account_file_copy(rdf_rejected_path, lpo_rejected_path, rejected_output_file_prefix, role_arn)


if __name__ == '__main__':
    if(len(sys.argv)) != 2:
        raise Exception("Insufficient input arguments provided......")

    logging.info("Loading input Dictionary values into dictionary.........")
    input_dict = dict(json.loads(sys.argv[1]))

    sales_target_path = str(input_dict.get('sales_target_path'))
    process_run_date = str(input_dict.get('run_date'))
    output_prefix = str(input_dict.get('output_file_prefix'))
    lpo_role_arn = input_dict.get('role_arn')
    lpo_target_path = input_dict.get("lpo_target_path")

    logging.info("Started the File transfer process into LPO buckets.........")
    copy_process(sales_target_path,lpo_target_path, process_run_date, output_prefix, lpo_role_arn)

    logging.info("Successfully transferred the files to LPO buckets...")

