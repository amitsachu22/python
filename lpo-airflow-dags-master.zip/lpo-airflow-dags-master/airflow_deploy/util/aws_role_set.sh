#!/usr/bin/env bash
#lpo_arn=arn:aws:iam::069272765570:role/dsmgplpo7d58b2d6-data-foundation-role

input_arn=$1
date_stamp=$(date "+%Y%m%d%H%M%S")

echo "This is the input arn provided: $input_arn"

echo "Calling AWS assume-role using sts client..."
aws sts assume-role --role-arn ${input_arn} --role-session-name DF_Assumed_role_session_${date_stamp} --region us-east-1 > temp_cred.txt

echo "Parsing role credentials..."
aws_access_key_id=$(cat temp_cred.txt | grep "AccessKeyId" | awk '{print $2}' | cut -d '"' -f 2)
aws_secret_access_key=$(cat temp_cred.txt | grep "SecretAccessKey" | awk '{print $2}' | cut -d '"' -f 2)
aws_session_token=$(cat temp_cred.txt | grep "Token" | awk '{print $2}' | cut -d '"' -f 2)

echo "Setting export variables to credential values..."
export AWS_ACCESS_KEY_ID=${aws_access_key_id}
export AWS_SECRET_ACCESS_KEY=${aws_secret_access_key}
export AWS_SESSION_TOKEN=${aws_session_token}
export AWS_DEFAULT_REGION=us-east-1

echo "the role has been assumed"


