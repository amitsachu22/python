#!/usr/bin/env bash
##!/usr/bin/env bash
#
# unset the temp creds to access the parent aws account
  echo " INFO : Clearing out AWS environment variables"
  unset AWS_ACCESS_KEY_ID
  unset AWS_DEFAULT_REGION
  unset AWS_SECRET_ACCESS_KEY
  unset AWS_SESSION_TOKEN

