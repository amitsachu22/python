# ==================================================================================
#
# inventory_ad_hoc.py
#
# If Boto3(aws component used in renaming files) is not installed in the cluster run this command:
#      "pip install --upgrade --user boto3"
# Run the following before application (copy  hive config file to the current directory)
#      "cp /etc/hive/conf/hive-site.xml ."
#
#
# Description: this script performs the following tasks
# 1. locates the hive tables required for sales product and location data.
# 2. filters data based on input parameters and processes the data.
# 3. Modifies the output filename and stores pipe delimited files in target bucket.
# 4. Renames the output file with stg_inventory_fact_yyyyMMddHHMMSS_file_num with a txt extension
#
# Parameters:
#               1. inventory_stg_path (mandatory)
#               2. inventory_cleaned_path (mandatory)
#               3. config_file (mandatory)
#               4. processing_region (mandatory)
#               5. run_date (mandatory)
#               6. output_file_prefix (mandatory)
#               7. Source Hive Tables and DB names (mandatory)
#               8. coalesce_val (optional)
#               9. error_file_path(mandatory)
#
# ==================================================================================
"""
History
=============================================================================================================
 Date           Author                  Desc
-------------------------------------------------------------------------------------------------------------
 05-14-2018     Vivek Reddy     New Script created
============================================================================================================

Sample Command to run:
spark-submit --master yarn --deploy-mode client --executor-memory 10G --driver-memory 12G \
--executor-cores 5 --num-executors 6 --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
--files hive-site.xml,utilities.py,inventory_load.prop inventory_ad_hoc.py '{"inventory_stg_path":"s3://nike-retail-stage/dev/lpo/stg/","inventory_cleaned_path":"s3://nike-retail-managed/dev/lpo/raw_data/","lpo_target_path":"s3://dsmgplpo7d58b2d6-non-us-east-1/sas/STG_INVENTORY_FACT/","inventory_db":"dtc_integrated","inventory_table":"dtc_bm_inventory_daily","digital_inventory_table":"dtc_doms_inventory_daily","location_db":"lpo","location_table":"location_gc","product_db":"lpo","product_table":"product","config_file":"inventory_load.prop","processing_region":"default_region", "run_date": "2018-05-30", "output_file_prefix":"stg_inventory","role_arn":"arn:aws:iam::069272765570:role/dsmgplpo7d58b2d6-data-foundation-role", "coalesce_val":"5"}'


spark-submit --master yarn --deploy-mode client --executor-memory 10G --driver-memory 12G \
--executor-cores 5 --num-executors 6 --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
--files hive-site.xml,,utilities.py,inventory_load.prop inventory_ad_hoc.py '{"inventory_stg_path":"s3://nike-retail-stage/dev/lpo/stg/","inventory_cleaned_path":"s3://nike-retail-stage/dev/lpo/raw_data/","error_file_path":"s3://nike-retail-stage/dev/lpo/rejected/","inventory_db":"dtc_integrated","inventory_table":"dtc_bm_inventory_daily","digital_inventory_table":"dtc_doms_inventory_daily","location_db":"lpo_test","location_table":"location","product_db":"lpo_test","product_table":"product","config_file":"inventory_load.prop","processing_region":"default_region", "run_date": "2018-05-30", "output_file_prefix":"stg_inventory", "coalesce_val":"5"}'

"""
import json
import logging
import sys
import datetime as dt
import time

# from pyspark.sql.functions import lit, col, row_number, date_format
import ConfigParser
import pyspark.sql.functions as F
from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
import utilities as util

try:
    import boto3
    import botocore
except ImportError as e:
    print("Not able to find boto libraires", e)
    sys.exit(1)

logging.basicConfig(level=logging.INFO)


def get_spark_session(appName):
    """
    :param appName: spark AppName to display in yarn
    :return: returns new spark session
    """
    session_config = [("spark.serializer", "org.apache.spark.serializer.KryoSerializer"),
                      ("spark.shuffle.compress", "true"),
                      ("spark.scheduler.mode", "FAIR"),
                      ("spark.sql.shuffle.partitions", "500"),
                      ("spark.memory.fraction","0.7"),
                      ]

    spark_conf = SparkConf().setAll(session_config) \
        .setAppName(appName)

    spark_session = SparkSession \
        .builder \
        .config(conf=spark_conf) \
        .enableHiveSupport() \
        .getOrCreate()

    spark_session.sparkContext.setLogLevel("WARN")

    return spark_session


def process_inventory_feed(input_config, spark, input_dict):
    """
    :param input_config: Configuration object to read the config file data
    :param spark: Spark session input to run the process
    :param input_dict: contains the necessary input argument from console
    """
    inventory_db = str(input_dict.get('inventory_db'))
    inventory_table = str(input_dict.get('inventory_table'))
    digital_inventory_table = str(input_dict.get('digital_inventory_table'))
    location_db = str(input_dict.get('location_db'))
    location_table = str(input_dict.get('location_table'))
    product_db = str(input_dict.get('product_db'))
    product_table = str(input_dict.get('product_table'))
    region_params = str(input_dict.get('processing_region'))
    run_date = str(input_dict.get('run_date'))
    error_file_path = str(input_dict.get('error_file_path'))


    region = input_config.get(region_params, 'region')

    start_date = input_config.get(region_params, 'start_date')

    end_date = input_config.get(region_params, 'end_date')
    store_code = input_config.get(region_params, 'store_code')

    logging.info("Loading the required input hive tables in spark session for invenory history process............")

    df_invent = spark.table("{0}.{1}".format(inventory_db, inventory_table)).filter(F.col("inv_snapshot_dt") >= start_date).select(F.col("eop_unit_qty"), F.col("inv_snapshot_dt"), F.col("str_id"), F.col("gtin"), F.col("region_cd"))

    if store_code == '3250' or store_code == '3721' or store_code == ' ':
        df_digital_inventory = spark.table("{0}.{1}".format(inventory_db, digital_inventory_table)).filter(F.col("sold_to_nbr").isin(['BZTMALL','BZNIKE'])).filter(F.col("inv_snapshot_dt") >= start_date).withColumn("str_id", F.when(F.col("sold_to_nbr") == "BZTMALL", "3721").otherwise("3250")).select(F.col("eop_unit_qty"), F.col("inv_snapshot_dt"), F.col("str_id"), F.col("gtin"), F.col("region_cd"))
        df_inventory = df_invent.union(df_digital_inventory)
        logging.info("Digital store_code")
    else :
        df_inventory = df_invent


    df_location = spark.table("{0}.{1}".format(location_db, location_table))
    df_product_raw = spark.table("{0}.{1}".format(product_db, product_table))


    logging.info("Started filtering the duplicate gtins from product dataset..........")
    df_product_filtered = df_product_raw.select(F.row_number().over(Window.partitionBy(F.col("gtin")).orderBy(F.col("gtin"))).alias('row_num'), df_product_raw['*'])
    df_product = df_product_filtered.filter(F.col("row_num") == 1).drop(F.col('row_num'))

    logging.info("filtering the inventory table based on region, end_date and store number provided..........")
    if region != '' :
        df_inventory = df_inventory.filter(F.col("region_cd") == region)
    if end_date != '' :
        df_inventory = df_inventory.filter(F.col("inv_snapshot_dt") <= end_date)

    if store_code != '':
        df_inventory = df_inventory.filter(F.col("str_id") == store_code)

    logging.info("This is the count for the b&m inventory before join: " + str(df_inventory.count()))

    df_inv = df_inventory.join(df_location,(df_inventory["str_id"] == df_location["location_name"])) \
                                                                           .join(df_product,(df_inventory["gtin"] == df_product["gtin"])).select(df_product["uuid"] \
                                                                          .alias("product_id"),df_location["location_id"], df_inventory["inv_snapshot_dt"].alias("start_dt"),
                                                                          df_inventory["eop_unit_qty"].alias("CLOSING_INVENTORY_QTY")).withColumn('OPENING_INVENTORY_QTY', F.lit(' ')).distinct()


    df_inv_f = df_inv.filter(df_inv.product_id.isNotNull() & df_inv.location_id.isNotNull() & df_inv.start_dt.isNotNull() & df_inv.CLOSING_INVENTORY_QTY.isNotNull()).filter(F.col("CLOSING_INVENTORY_QTY") >= 0).filter(F.col("start_dt") <= run_date)

    logging.info("This is the count for the inventory after joining b&m and digital: " + str(df_inv_f.count()))

    return df_inv_f


if __name__ == '__main__':
    if(len(sys.argv)) != 2:
        raise Exception("Insufficient input arguments provided......")

    logging.info("Loading input Dictionary values into dictionary.........")
    input_dict = dict(json.loads(sys.argv[1]))

    inventory_stage_path = str(input_dict.get('inventory_stg_path'))
    df_cleaned_path = str(input_dict.get('inventory_cleaned_path'))
    coalesce_val = str(input_dict.get('coalesce_val')) if str(input_dict.get('coalesce_val')) != '' else '5'
    config_file = input_dict.get('config_file')
    process_run_date = str(input_dict.get('run_date'))
    output_prefix = str(input_dict.get('output_file_prefix'))
    lpo_role_arn = input_dict.get('role_arn')
    lpo_target_path = input_dict.get("lpo_target_path")
    input_file_format = "csv"
    output_file_format = "txt.gz"

    inventory_cleaned_path = df_cleaned_path + process_run_date + "/"

    run_dt_format = dt.datetime.strptime(process_run_date,'%Y-%m-%d')
    file_date = run_dt_format.strftime("%Y%m%d")

    output_file_prefix = output_prefix + "_" + file_date

    logging.info("Number of input Arguments Passed: {0}".format(len(sys.argv)))
    logging.info("Arguments passed: {0}".format(str(sys.argv)))

    logging.info("   inventory_stage_path     : " + inventory_stage_path)
    logging.info("   inventory_cleaned_path   : " + inventory_cleaned_path)
    logging.info("   coalesce_val         : " + coalesce_val)

    logging.info("Loading arguments from the config file.........")
    conf = ConfigParser.ConfigParser()
    conf.read(config_file)

    logging.info("Instantiate Spark Session.........")
    sparkSession = get_spark_session("Inventory_hist")

    logging.info("starting the spark process for given sales feed.......")

    process_start_time = time.time()
    inventory_df = process_inventory_feed(conf, sparkSession, input_dict)

    inventory_df.coalesce(int(coalesce_val)).write.format(input_file_format) \
        .mode("overwrite").option('delimiter', '|') \
        .option("codec", "org.apache.hadoop.io.compress.GzipCodec") \
        .option('header', 'true') \
        .save(inventory_stage_path)

    process_end_time = time.time()


    print ('process_end_time', process_end_time)

    logging.info("Time taken to process invetory history: {0}".format(str(process_end_time - process_start_time)))

    logging.info("Started the file renaming process by passing the file prefix and file format...............")
    util.copy_files_to_s3target(inventory_stage_path, inventory_cleaned_path, output_file_prefix, input_file_format, output_file_format)

    logging.info("started cleaned sales files transfer to LPO AWS buckets......................... ")
    util.cross_account_file_copy(inventory_cleaned_path, lpo_target_path, output_file_prefix, lpo_role_arn)

    logging.info("Terminating spark session.....")
    sparkSession.stop()


