import sys
import logging
import re
import os

# imports required for PySpark
try:
    from pyspark.sql import SparkSession
    from pyspark.sql import DataFrame
    from pyspark.sql.functions import *
except ImportError as e:
    print ("Error importing Spark Modules", e)
    sys.exit(1)

# Configure logger object for logging messages

logger = logging.getLogger("Deriving Sales for LPO From DF")
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler())

# Spark configuration parameters :
hiveContext = SparkSession.builder.config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
    .config("spark.shuffle.compress", "true") \
    .config("spark.scheduler.mode", "FAIR") \
    .config("spark.speculation", "true") \
    .config("spark.default.parallelism", "500") \
    .config("spark.sql.files.maxPartitionBytes","1024")\
    .appName("LPO_Sales_History_Load") \
    .enableHiveSupport().getOrCreate()

df_dtc_daily = hiveContext.sql("select * from  dev_rdf.global_dtc_daily_demand")
df_location = hiveContext.sql("select * from  lpo_test.location")
df_product_der = hiveContext.sql("select * from  lpo_test.product_der")


df_tmp = df_dtc_daily.join(df_location,(df_dtc_daily["store_code"] == df_location["store_code"])) \
                     .join(df_product_der,(df_dtc_daily["upc_code"] == df_product_der["gtin"]),"left_outer") \
                     .where(df_dtc_daily["geo_part"] == 'CHN') \
                     .select(df_product_der["uuid"].alias("product_id"),
                             df_location["location_id"],
                             date_format(df_dtc_daily["local_transaction_date"],"dd/MM/yyyy").alias("start_dt"),
                             df_dtc_daily["integrated_released_sales_amount"].alias("sales_amt"),
                             df_dtc_daily["integrated_released_sales_units"].alias("sales_qty"),
                             df_dtc_daily["integrated_returned_sales_amount"].alias("return_amt"),
                             df_dtc_daily["integrated_returned_sales_units"].alias("return_qty")).distinct()
 

df_tmp.coalesce(1).write.format('csv').option('delimiter','|').option('header','true').save('s3://nike-retail-stage/dev/lpotest/sales_hist/')


