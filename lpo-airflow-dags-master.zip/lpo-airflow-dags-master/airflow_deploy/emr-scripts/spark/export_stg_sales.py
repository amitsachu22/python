# ==================================================================================
#
# export_stg_sales.py
#
# Given inclusive beginning or duration, fetch sales and map gtin to product id, store code to location_id
# Merge partitions, gzip, assume role and push to remote S3
# Save to S3 by date and time
#
# If Boto3(aws component used in renaming files) is not installed in the cluster run this command:
#      "pip install --upgrade --user boto3"
#
# Workflow performs the following actions: [todo]
#
#
# Parameters:
#   Expects an input json object containing:
#       - app_name              : Application Name (optional)
#       - env_name              : Runtime environment name, one of sbx, non, prd
#       - sales_load            : Sales load property file name
#       - env_properties        : Environment properties file name
#
# ==================================================================================
"""
History
=============================================================================================================
 Date           Author                  Desc
-------------------------------------------------------------------------------------------------------------
 05-23-2019     Dan Logan       Initial workflow
============================================================================================================
Sample Command to run:
    spark-submit --master yarn --deploy-mode client --executor-memory 10G --driver-memory 12G \
          --executor-cores 2 --num-executors 18 --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 --files /etc/hive/conf/hive-site.xml, export_stg_sales.py \
              '{ "lpo_db": "dev_dsm_lpo", "duration": "1", "temp_base_path": "s3://ngap2-user-data/dstiengineering/lpo/dstiengineeringdev/sales/stg_sales_fact", "target_base_path": "s3://dsmdemand117f359-non-us-east-1/data/ngap/daily/stg_sales_fact/region=GC", "assume_role_arn": "arn:aws:iam::069272765570:role/dsmdemand117f359-data-foundation-role" }'
"""
import sys, logging, time
import sys
import lpo_common_functions as l
import export2thecommons as e
import json
from pyspark.sql.functions import col, min, max, sum

### geo_part defaults to 'CHN', start_date defaults to '2015-06-01' ; if not provided
def fetchSalesTable(spark_session, start_date='2015-06-01', geo_part='CHN'):
    return spark_session.table('rdf.global_dtc_daily_demand') \
                    .filter(col('geo_part') == geo_part) \
                    .filter(col('local_transaction_date_part') >= start_date) \
                    .filter("local_transaction_date is not null or local_transaction_date != ''") \
                    .filter(col("flavor_of_sale") != "COMPLIMENTARY") \
                    .select(col('upc_code').alias('gtin'), \
                        col('store_code'), \
                        col('local_transaction_date_part').alias("start_dt"), \
                        col('integrated_released_sales_amount').alias("sales_amt"), \
                        col('integrated_released_sales_units').alias("sales_qty"), \
                        col('integrated_returned_sales_amount').alias("return_amt"), \
                        col('integrated_returned_sales_units').alias("return_qty")) \
                    .groupBy(col("start_dt"), col("store_code"), col("gtin")) \
                    .agg(sum(col("sales_amt")), sum(col("sales_qty")), sum(col("return_amt")), sum(col("return_qty"))) \
                    .withColumnRenamed("sum(sales_amt)","sales_amt") \
                    .withColumnRenamed("sum(sales_qty)","sales_qty") \
                    .withColumnRenamed("sum(return_amt)","return_amt") \
                    .withColumnRenamed("sum(return_qty)","return_qty") \
                    .filter("sales_qty != 0 or return_qty != 0 or sales_amt != 0 or return_amt != 0") \

def fetchLocationTable(spark_session, lpo_db='dsm_lpo'):
    return spark_session.table("{db}.location_gc".format(db=lpo_db)) \
                        .select("location_id", col("location_name").alias("site_code")) \
                        .distinct();

def fetchProductTable(spark_session, regionCode="GC", lpo_db='dsm_lpo'):
    return spark_session.table("{db}.product_by_geo".format(db=lpo_db)) \
                        .filter(col("geo") == regionCode) \
                        .select(col("gtin"), col("sku_id")) \
                        .distinct()

def map_sales_to_lpo_identifiers(spark_session, sales, product, location):
    product.persist()
    location.persist()

    stg_sales = sales.join(product, [sales["gtin"] == product["gtin"]], "inner") \
        .join(location, [sales["store_code"] == location["site_code"]], "inner") \
        .select(col("sku_id").alias("product_id"), \
            col("location_id"), \
            col("start_dt"), \
            col("sales_amt"), \
            col("sales_qty"), \
            col("return_amt"), \
            col("return_qty"))
    return stg_sales

def get_start_date(parameters, config):
    """Calculating start date to be used for extract.
        Start is either 2015-06-01 for full load, or calculated from today based on a provided duration.
        Duration can be provided from parameters for from sales_load properties.
    """
    if parameters.get("is_full_load") == True:
        return '2015-06-01'
    duration = parameters.get("duration")
    if duration is None:
        sales_load_region_key = l.getOrDefault(parameters, "sales_load_region_key", "default_region")
        duration = config.get(sales_load_region_key, "process_days")
    return l.calculate_start_date(duration)

if __name__ == '__main__':

    if(len(sys.argv)) != 2:
        raise Exception("Expecting single parameter, dictionary containing parameters")

    logging.basicConfig(level=logging.INFO)
    logging.info("Initiating...")

    parameters = dict(json.loads(sys.argv[1]))

    config_file_keys = []
    config_file_keys.append(l.get(parameters, 'sales_load'))
    config_file_keys.append(l.get(parameters, 'env_properties'))
    config_file_keys.append(l.get(parameters, 'splunk_properties'))
    config = l.get_config(config_file_keys)

    env_name = l.getOrDefault(parameters, 'env_name', 'prd')

    if env_name not in ['sbx', 'non', 'prd']:
        raise Exception("env_name was not an expected value")

    app_name = l.getOrDefault(parameters, 'app_name', 'export_stg_sales')

    splunk_handler = l.get_splunk_handler(config, env_name, app_name)
    logging.getLogger('').addHandler(splunk_handler)

    try:
        spark_session = l.create_spark_session(app_name)
        logging.info("Spark session initialized, process begin...")
        process_start_time = time.time()

        start_date = get_start_date(parameters, config)
        lpo_db = config.get(env_name, "lpo_db")

        sales = fetchSalesTable(spark_session, start_date)
        inbound_sales_count = sales.count()
        logging.info("Inbound sales count: {}".format(inbound_sales_count))

        location = fetchLocationTable(spark_session=spark_session)
        location_count = location.count()
        logging.info("Location count: {}".format(location_count))

        product = fetchProductTable(spark_session=spark_session, regionCode="GC", lpo_db=lpo_db)
        product_count = product.count()
        logging.info("Product count: {}".format(product_count))

        mapped_sales_all = map_sales_to_lpo_identifiers(spark_session, sales, product, location)
        mapped_sales_count = mapped_sales_all.count()

        logging.info("Outbound sales count: {}".format(mapped_sales_count))
        logging.info("Discarded sales count: {}".format(inbound_sales_count - mapped_sales_count))

        header = l.getOrDefault(parameters, "header_row", "product_id|location_id|start_dt|sales_amt|sales_qty|return_amt|return_qty\n")
        temp_base_path = config.get(env_name, "temp_base_path")
        target_base_path = config.get(env_name, "target_base_path")
        filename_base = "stg_sales_fact"
        assume_role_arn = config.get(env_name, "assume_role_arn")
        current_iso_date = l.calculate_current_iso_date()
        current_time_in_millis = l.get_current_time_in_millis()
        allow_gzip = l.getOrDefault(parameters, "allow_gzip", False)

        e.export(
            source_df = mapped_sales_all,
            header = header,
            temp_base_path = temp_base_path,
            target_base_path = target_base_path,
            filename_base = filename_base,
            role_arn = assume_role_arn,
            date_part = current_iso_date,
            time_in_millis = current_time_in_millis,
            allow_gzip = allow_gzip
        )

        logging.info("Finished...")
        process_end_time = time.time()
        logging.info("Processing took {} seconds...".format(str(process_end_time - process_start_time)))

        spark_session.stop()
    except:
        logging.exception("A fatal error occurred")
        raise
