# ==================================================================================
#
# sales_daily_load.py
#
# Description: this script performs the following tasks
# 1. Process the sales feed to with the given input range defined in config file
# 1. locates the hive tables required for sales product and location data.
# 2. filters data based on input parameters and processes the data.
# 3. Modifies the output filename and stores pipe delimited files in target bucket.
#
# Parameters:
#               1. sales_stg_path (mandatory)
#               2. sales_cleaned_path (mandatory)
#               3. config_file (mandatory)
#               4. processing_region (mandatory)
#               5. run_date (mandatory)
#               6. output_file_prefix (mandatory)
#               7. Source Hive Tables and DB names (mandatory)
#               8. coalesce_val (optional)
#
# ==================================================================================
"""
History
=============================================================================================================
 Date           Author                  Desc
-------------------------------------------------------------------------------------------------------------
 05-10-2018     Naveen Raj Kurapati     New Script created
 07-10-2018     Naveen Raj Kurapati     Added the methods for cross account file transfers and handling reject files.
============================================================================================================

Sample Command to run:
spark-submit --master yarn --deploy-mode client --executor-memory 10G --driver-memory 12G \
--executor-cores 5 --num-executors 6 --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
--files hive-site.xml,utilities.py,sales_load.prop sales_daily_load.py 
{
  "sales_stg_path": "s3://nike-retail-stage/dev/lpo/",
  "sales_target_path": "s3://nike-retail-managed/dev/rawdata/lpo/",
  "lpo_target_path": "s3://dsmgplpo7d58b2d6-non-us-east-1/sas/STG_SALES_FACT/",
  "sales_db": "rdf",
  "sales_table": "global_dtc_daily_demand",
  "location_db": "lpo_test",
  "location_table": "location",
  "product_db": "lpo_test",
  "product_table": "product",
  "config_file": "sales_load.prop",
  "processing_region": "default_region",
  "run_date": "2018-06-26 10:20:05",
  "output_file_prefix": "stg_sales_fact",
  "role_arn": "arn:aws:iam::069272765570:role/dsmgplpo7d58b2d6-data-foundation-role",
  "coalesce_val": "1"
}

spark-submit --master yarn --deploy-mode client --executor-memory 10G --driver-memory 12G \
--executor-cores 5 --num-executors 6 --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
--files hive-site.xml,utilities.py,sales_load.prop sales_daily_load.py 
{
  "sales_stg_path": "s3://nike-retail-stage/dev/lpo/stg/",
  "sales_target_path": "s3://nike-retail-stage/dev/lpo/rawdata/",
  "lpo_target_path": "s3://dsmgplpo7d58b2d6-non-us-east-1/sas/STG_SALES_FACT/",
  "sales_table": "rdf.global_dtc_daily_demand",
  "location_table": "lpo_test.location",
  "product_table": "lpo_test.product",
  "config_file": "sales_load.prop",
  "processing_region": "default_region",
  "run_date": "2018-07-01 10:20:05",
  "output_file_prefix": "stg_sales_fact",
  "role_arn": "arn:aws:iam::069272765570:role/dsmgplpo7d58b2d6-data-foundation-role",
  "coalesce_val": "1"
}

"""

import logging
import json
import sys
import subprocess
from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
import pyspark.sql.functions as F
from pyspark.sql.functions import sum as sparkSum
import ConfigParser
import time
import datetime as dt
import utilities as util

logging.basicConfig(level=logging.ERROR)


def get_spark_session(appName):
    """
    :param appName: spark AppName to display in yarn
    :return: returns new spark session
    """
    session_config = [("spark.shuffle.compress", "true"), ("spark.scheduler.mode", "FAIR"),
                      ("spark.sql.shuffle.partitions", "500"),("mapred.input.dir.recursive", "true"),
                      ("spark.sql.hive.convertMetastoreParquet", "false"),
                      ("spark.driver.maxResultSize", "0")]

    spark_conf = SparkConf().setAll(session_config) \
        .setAppName(appName)

    spark_session = SparkSession \
        .builder \
        .config(conf=spark_conf) \
        .enableHiveSupport() \
        .getOrCreate()

    spark_session.sparkContext.setLogLevel("ERROR")

    return spark_session


def process_sales_feed(input_config, spark, input_dict):
    """
    :param input_config: Configuration object to read the config file data
    :param spark: Spark session input to run the process
    :param input_dict: contains the necessary input argument from console
    :return: processed sales DataFrame with caps id in schema
    """

    sales_table = str(input_dict.get('sales_table'))
    location_table = str(input_dict.get('location_table'))
    product_table = str(input_dict.get('product_table'))
    region_params = str(input_dict.get('processing_region'))
    airflow_args = input_dict.get('airflow_args')
    run_date = str(input_dict.get('run_date'))

    logging.info("--------------------------> Loaded airflow arg dict:{0}".format(airflow_args))

    date_curr = dt.datetime.strptime(run_date,'%Y-%m-%d') if run_date != '' else dt.datetime.utcnow()
    current_date = date_curr.strftime("%Y-%m-%d")

    country = input_config.get(region_params, 'country')
    region = input_config.get(region_params, 'region')

    processing_days = airflow_args["process_days"] if "process_days" in airflow_args and airflow_args["process_days"] != '' else input_config.get(region_params, 'process_days') if input_config.get(region_params, 'process_days') != '' else '10'

    process_start_date = date_curr - dt.timedelta(int(processing_days))

    start_date = airflow_args["start_date"] if "start_date" in airflow_args and airflow_args["start_date"] != '' else input_config.get(region_params, 'start_date') if input_config.get(region_params, 'start_date') != '' else process_start_date.strftime("%Y-%m-%d")

    end_date = airflow_args["end_date"] if "end_date" in airflow_args and airflow_args["end_date"] != '' else input_config.get(region_params, 'end_date') if input_config.get(region_params, 'end_date') != '' else current_date

    store_number = airflow_args["store_number"] if "store_number" in airflow_args and airflow_args["store_number"] != '' else input_config.get(region_params, 'store_number')

    logging.info("Loading the required input hive tables in spark session for sales process............")

    df_dtc_daily_demand = spark.table("{0}".format(sales_table)) \
        .filter("local_transaction_date is not null or local_transaction_date !='' ").repartition(30)

    df_location = spark.table("{0}".format(location_table)) \
        .filter("location_id is not null or location_id != '' ")

    # logging.info("This is the count for total products info : {0}".format(str(df_product_raw.count())))

    logging.info("Started filtering the duplicate gtins from product dataset..........")

    # Filter dupes
    df_product_raw = spark.table("{0}".format(product_table)) \
        .filter("uuid is not null or uuid != '' ") \
        .orderBy(F.asc("gtin"),F.desc("effective_date")) \
        .select(F.monotonically_increasing_id().alias("rowNum"), "*") \
        .persist()

    df_product_max_by_gtin = df_product_raw.groupBy("gtin").agg(F.max(F.col("rowNum")))

    df_product = df_product_raw.join(df_product_max_by_gtin, [df_product_max_by_gtin["gtin"] == df_product_raw["gtin"], df_product_max_by_gtin["max(rowNum)"] == df_product_raw["rowNum"]], "inner") \
                               .drop(df_product_max_by_gtin["gtin"])

    logging.info("Filtering df_dtc_daily_demand on: country:{0}; region:{1}; processing days:{2}; start_date:{3}; end_date:{4}; store_number:{5}".format(country, region, processing_days, start_date, end_date, store_number))

    df_dtc_daily_filtered = df_dtc_daily_demand.filter(F.col("flavor_of_sale") != "COMPLIMENTARY") \
                                               .filter(F.col("geo_part") == region)
    if start_date:
        df_dtc_daily_filtered = df_dtc_daily_filtered.filter(F.col("local_transaction_date_part") >= start_date)
    if end_date:
        df_dtc_daily_filtered = df_dtc_daily_filtered.filter(F.col("local_transaction_date_part") <= end_date)
    if store_number:
        df_dtc_daily_filtered = df_dtc_daily_filtered.filter(F.col("store_code") == store_number)
    if country:
        df_dtc_daily_filtered = df_dtc_daily_filtered.filter(F.col("iso_country_code") == country)

    # logging.info("This is the count for the df_sales before join: " + str(df_dtc_daily_filtered.count()))

    df_sales_raw = df_dtc_daily_filtered.join(df_location,
                                              (df_dtc_daily_filtered["store_code"] == df_location["location_name"]), "left_outer") \
        .join(df_product, (df_dtc_daily_filtered["upc_code"] == df_product["gtin"]), "left_outer") \
        .select(df_product["uuid"].alias("product_id"),
                df_location["location_id"],
                F.date_format(df_dtc_daily_filtered["local_transaction_date"], "yyyy-MM-dd").alias("start_dt"),
                df_dtc_daily_filtered["integrated_released_sales_amount"].alias("sales_amt"),
                df_dtc_daily_filtered["integrated_released_sales_units"].alias("sales_qty"),
                df_dtc_daily_filtered["integrated_returned_sales_amount"].alias("return_amt"),
                df_dtc_daily_filtered["integrated_returned_sales_units"].alias("return_qty")).groupBy(F.col("start_dt"), F.col("location_id"), F.col("product_id")).agg(sparkSum(F.col("sales_amt")), sparkSum(F.col("sales_qty")), sparkSum(F.col("return_amt")), sparkSum(F.col("return_qty"))). \
        withColumnRenamed("sum(sales_amt)","sales_amt").withColumnRenamed("sum(sales_qty)","sales_qty"). \
        withColumnRenamed("sum(return_amt)","return_amt").withColumnRenamed("sum(return_qty)","return_qty")

    df_sales_cleaned = df_sales_raw.filter("location_id is not null") \
        .filter("location_id != ''") \
        .filter("product_id is not null") \
        .filter("product_id != ''")

    df_sales_rejected = df_sales_raw.subtract(df_sales_cleaned)

    logging.info("Filter records if the sales qty or return qty is zero amount...........")

    df_sales = df_sales_cleaned.filter("sales_qty != 0 or return_qty != 0 or sales_amt != 0 or return_amt != 0")

    return [df_sales, df_sales_rejected]


if __name__ == '__main__':
    if(len(sys.argv)) != 2:
        raise Exception("Insufficient input arguments provided......")

    logging.info("Loading input Dictionary values into dictionary.........")
    input_dict = dict(json.loads(sys.argv[1]))

    sales_stage_path = str(input_dict.get('sales_stg_path'))
    sales_target_path = str(input_dict.get('sales_target_path'))
    lpo_target_path = str(input_dict.get('lpo_target_path'))
    coalesce_val = str(input_dict.get('coalesce_val')) if str(input_dict.get('coalesce_val')) != '' else '1'
    config_file = input_dict.get('config_file')
    process_run_date = str(input_dict.get('run_date'))
    output_prefix = str(input_dict.get('output_file_prefix'))
    file_format = "csv"
    target_file_format = "txt"
    role_arn = str(input_dict.get('role_arn'))

    run_dt_format = dt.datetime.strptime(process_run_date,'%Y-%m-%d')
    file_date = run_dt_format.strftime("%Y%m%d%H%M%S")

    cleaned_output_file_prefix = output_prefix + "_" + file_date
    rejected_output_file_prefix = output_prefix + "_rejected_" + file_date

    sales_cleaned_path = sales_target_path + str(process_run_date) + "/sales_cleaned/"
    sales_rejected_path = sales_target_path + str(process_run_date) + "/sales_rejected/"

    sales_stage_rejected = sales_stage_path + "sales_stage_rejected/"
    sales_stage = sales_stage_path + "sales_stage/"

    logging.info("Number of input Arguments Passed: {0}".format(len(sys.argv)))
    logging.info("Arguments passed: {0}".format(str(sys.argv)))

    logging.info("   sales_stage_path     : " + sales_stage_path)
    logging.info("   sales_target_path   : " + sales_target_path)
    logging.info("   coalesce_val         : " + coalesce_val)

    logging.info("Loading arguments from the config file.........")
    conf = ConfigParser.ConfigParser()
    conf.read(config_file)

    logging.info("Intiate Spark Session.........")
    sparkSession = get_spark_session("LPO_Sales_Load")

    logging.info("starting the spark process for given sales feed.......")

    process_start_time = time.time()

    sales_data = process_sales_feed(conf, sparkSession, input_dict)

    sales_df = sales_data[0]

    sales_df.persist()

    sales_rejected_df = sales_data[1]

    sales_rejected_df.persist()

    # logging.info("Total Sales records processed is: {0}".format(int(sales_df.count())))
    # logging.info("Total Sales records rejected is: {0}".format(int(sales_rejected_df.count())))

    logging.info("writing sales feed to s3 location..........")
    sales_df.coalesce(int(coalesce_val)).write.format(file_format) \
        .mode("overwrite").option('delimiter', '|') \
        .option('header', 'true') \
        .save(sales_stage)

    logging.info("writing sales rejected files to s3 location..........")
    sales_rejected_df.coalesce(int(coalesce_val)).write.format(file_format) \
        .mode("overwrite").option('delimiter', '|') \
        .option('header', 'true') \
        .save(sales_stage_rejected)

    process_end_time = time.time()

    logging.info("Time taken to process sales feed: {0}".format(str(process_end_time - process_start_time)))

    logging.info("Started the clean file copy with rename from stage:{0} to cleaned:{1}".format(sales_stage,sales_cleaned_path))
    util.copy_files_to_s3target(sales_stage, sales_cleaned_path, cleaned_output_file_prefix, file_format, target_file_format)

    logging.info("Started the reject file copy with rename from stage:{0} to cleaned:{1} ".format(sales_stage_rejected,sales_rejected_path))
    util.copy_files_to_s3target(sales_stage_rejected, sales_rejected_path, rejected_output_file_prefix, file_format, target_file_format)

    cleaned_output_file_prefix = output_prefix + "_" + file_date
    rejected_output_file_prefix = output_prefix + "_rejected_" + file_date

    rdf_cleaned_path = sales_target_path + str(process_run_date) + "/sales_cleaned/"
    lpo_cleaned_path = lpo_target_path + "sales_cleaned/date=" + process_run_date + "/"
    rdf_rejected_path = sales_target_path + str(process_run_date) + "/sales_rejected/"
    lpo_rejected_path = lpo_target_path + "sales_rejected/date=" + process_run_date + "/"

    logging.info("started cleaned sales files transfer from {0} to {1}".format(rdf_cleaned_path, lpo_cleaned_path))
    util.cross_account_file_copy(rdf_cleaned_path, lpo_cleaned_path, cleaned_output_file_prefix, role_arn)

    logging.info("started cleaned sales rejected files transfer from {0} to {1}".format(rdf_rejected_path, lpo_rejected_path))
    util.cross_account_file_copy(rdf_rejected_path, lpo_rejected_path, rejected_output_file_prefix, role_arn)

    logging.info("Terminating spark session.....")
    sparkSession.stop()
