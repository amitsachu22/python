# ==================================================================================
#
# export_stg_price.py
#
# Given inclusive beginning or duration, fetch prices and map gtin to product id, store code to location_id
# Split data set to initial price and markdown price, publish both result sets.
# For both result sets:
# Merge partitions, gzip, assume role and push to remote S3
# Save to S3 by date and time
#
# If Boto3(aws component used in renaming files) is not installed in the cluster run this command:
#      "pip install --upgrade --user boto3"
#
# Workflow performs the following actions: [todo]
#
# Parameters:
#   Expects an input json object containing:
#       - app_name              : Application Name (optional)
#       - env_name              : Runtime environment name, one of sbx, non, prd
#       - price_load            : Price load property file name
#       - env_properties        : Environment properties file name
#
# ==================================================================================
"""
History
=============================================================================================================
 Date           Author                  Desc
-------------------------------------------------------------------------------------------------------------
 06-11-2019     Dan Logan       Initial workflow
============================================================================================================
"""
import sys, logging, time
import sys
import lpo_common_functions as l
import export2thecommons as e
import json
from pyspark.sql.functions import col, min, max, sum, lit
from pyspark.sql.types import StringType

### geo_part defaults to 'CHN', start_date defaults to '2015-06-01' ; if not provided
def fetchPriceTable(spark_session, start_date='2015-01-01', region_code = 'CN'):
    return spark_session.table('rdf.price_change') \
                    .filter(col('region_cd_part') == region_code) \
                    .filter(col('effective_date') >= '2015-01-01') \
                    .select(col('item_gtin').alias('gtin'), \
                        col('location_code').alias('site_code'), \
                        col('effective_date').alias('start_dt'), \
                        col('current_selling_price_amount').alias('price'), \
                        col('price_currency').alias('currency_cd'), \
                        col('price_pricetype').alias('type'))

def fetchLocationTable(spark_session, lpo_db='dsm_lpo'):
    return spark_session.table("{db}.location_gc".format(db=lpo_db)) \
                        .select("location_id", col("location_name").alias("site_code")) \
                        .distinct();

def fetchProductTable(spark_session, regionCode="GC", lpo_db='dsm_lpo'):
    return spark_session.table("{db}.product_by_geo".format(db=lpo_db)) \
                        .filter(col("geo") == regionCode) \
                        .select(col("gtin"), col("sku_id")) \
                        .distinct()

def map_price_to_lpo_identifiers(spark_session, price, product, location):
    product.persist()
    location.persist()
    stg_price = price.join(product, [price["gtin"] == product["gtin"]], "inner") \
        .join(location, [price["site_code"] == location["site_code"]], "inner") \
        .select(col("sku_id").alias("product_id"), \
            col("location_id"), \
            col("start_dt"), \
            col("price"), \
            col("currency_cd"), \
            col("type"))
    return stg_price

def filter_price_by_type(price, is_initial=True):
    return price.filter((col("type") == 'REGULAR') if is_initial else (col("type") != 'REGULAR')) \
                .select(col("product_id"), \
                    col("location_id"), \
                    col("start_dt"), \
                    col("price"), \
                    col("currency_cd"))

def get_start_date(parameters, config):
    return '2015-01-01'

if __name__ == '__main__':

    if(len(sys.argv)) != 2:
        raise Exception("Expecting single parameter, dictionary containing parameters")

    logging.basicConfig(level=logging.INFO)
    logging.info("Initiating...")

    parameters = dict(json.loads(sys.argv[1]))

    config_file_keys = []
    config_file_keys.append(l.get(parameters, 'env_properties'))
    config = l.get_config(config_file_keys)

    env_name = l.getOrDefault(parameters, 'env_name', 'prd')

    if env_name not in ['sbx', 'non', 'prd']:
        raise Exception("env_name was not an expected value")

    app_name = l.getOrDefault(parameters, 'app_name', 'export_stg_price')
    spark_session = l.create_spark_session(app_name)

    logging.info("Spark session initialized, process begin...")
    process_start_time = time.time()

    start_date = get_start_date(parameters, config)
    lpo_db = config.get(env_name, "lpo_db")

    price = fetchPriceTable(spark_session, start_date)
    location = fetchLocationTable(spark_session=spark_session)
    product = fetchProductTable(spark_session=spark_session, regionCode="GC", lpo_db=lpo_db)
    mapped_price_all = map_price_to_lpo_identifiers(spark_session, price, product, location)
    stg_initial_price = filter_price_by_type(mapped_price_all, True)
    stg_mkd_price = filter_price_by_type(mapped_price_all, False)

    temp_base_path = config.get(env_name, "temp_base_path")
    target_base_path = config.get(env_name, "target_base_path")
    initial_price_filename_base = "stg_initial_price_fact"
    mkd_price_filename_base = "stg_mkd_price_fact"
    assume_role_arn = config.get(env_name, "assume_role_arn")
    current_iso_date = l.calculate_current_iso_date()
    current_time_in_millis = l.get_current_time_in_millis()
    allow_gzip = l.getOrDefault(parameters, "allow_gzip", False)

    # Export initial price
    e.export(
        source_df = stg_initial_price,
        header = "product_id|location_id|start_dt|initial_price|currency_cd\n",
        temp_base_path = temp_base_path.format(filename=initial_price_filename_base),
        target_base_path = target_base_path.format(filename=initial_price_filename_base),
        filename_base = initial_price_filename_base,
        role_arn = assume_role_arn,
        date_part = current_iso_date,
        time_in_millis = current_time_in_millis,
        allow_gzip = allow_gzip
    )

    # Export mkd price
    e.export(
        source_df = stg_mkd_price,
        header = "product_id|location_id|start_dt|mkd_price|currency_cd\n",
        temp_base_path = temp_base_path.format(filename=mkd_price_filename_base),
        target_base_path = target_base_path.format(filename=mkd_price_filename_base),
        filename_base = mkd_price_filename_base,
        role_arn = assume_role_arn,
        date_part = current_iso_date,
        time_in_millis = current_time_in_millis,
        allow_gzip = allow_gzip
    )

    logging.info("Finished...")
    process_end_time = time.time()
    logging.info("Processing took {} seconds...".format(str(process_end_time - process_start_time)))

    spark_session.stop()
