# ==================================================================================
#
# product_daily_load.py
#
# If Boto3(aws component used in renaming files) is not installed in the cluster run this command:
#      "pip install --upgrade --user boto3"
# Run the following before application (copy  hive config file to the current directory)
#      "cp ../hadoop/../hadoop/../../etc/hive/conf/hive-site.xml ."
#
#
# Description: this script performs the following tasks
# 1. locates the data in LPO s3 and copies to Data Foundation s3 (TBA).
# 2. filters data based on input parameters and processes the data.
# 3. Stores the processed data into a hive table(daily incremental transactional table).
#
# Parameters:
#               1. input_path (mandatory)
#               2. Hive Tables and DB names (mandatory)
#
#
# ==================================================================================
"""
History
=============================================================================================================
 Date           Author                  Desc
-------------------------------------------------------------------------------------------------------------
 06-26-2018     Vivek Reddy     New Script created
============================================================================================================

Sample Command to run:
spark-submit --master yarn --deploy-mode client --executor-memory 10G --driver-memory 12G \
--executor-cores 5 --num-executors 6 --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 \
--files hive-site.xml, product_daily_load.py '{"input_path":"s3://nike-retail-stage/dev/rawdata/lpo/product_stg/","target_path":"s3://nike-retail-managed/dev/rawdata/lpo/product/","product_db":"lpo","product_table":"product", "run_dt":"2018-07-24"}'

"""
import logging
import subprocess
import sys
import json
import time


# from pyspark.sql.functions import lit, col, row_number, date_format
from pyspark import SparkConf
from pyspark.shell import sqlContext
from pyspark.sql import SparkSession
import pyspark.sql.functions as F

try:
    import boto3
    import botocore
except ImportError as e:
    print("Not able to find boto libraires", e)
    sys.exit(1)

logging.basicConfig(level=logging.INFO)


def get_spark_session(appName):
    """
    :param appName: spark AppName to display in yarn
    :return: returns new spark session
    """
    session_config = [("spark.serializer", "org.apache.spark.serializer.KryoSerializer"),
                      ("spark.shuffle.compress", "true"),
                      ("spark.scheduler.mode", "FAIR"),
                      ("spark.sql.shuffle.partitions", "500"),
                      ("spark.memory.fraction","0.7")
                      ]

    spark_conf = SparkConf().setAll(session_config) \
        .setAppName(appName)

    spark_session = SparkSession.builder \
        .config(conf=spark_conf) \
        .enableHiveSupport() \
        .getOrCreate()

    spark_session.sparkContext.setLogLevel("WARN")

    return spark_session

def process_product_feed(spark, input_dict):

    input_path = str(input_dict.get('input_path'))


    Raw_df = spark.read.json(input_path) # reads the JSON data

    Raw_df.registerTempTable("product_temp") # creates temp table on the json data

    # empty cols will come from second file provided by LPO backend
    # exploding due to multiple gtin per style/color (6-7)
    product_df = sqlContext.sql(
        """
        SELECT id AS style_color_cd, 
               lpad(skus1.gtins.activeGtin.gtin,14,'0') AS gtin,
               skus1.id AS uuid, 
               style.code AS style_code, 
               color.code AS color_code, 
               skus1.code AS size_code, 
               ' ' AS gender, 
               ' ' AS division, 
               ' ' AS category, 
               ' ' AS classification, 
               CASE 
                    WHEN skus1.gtins.activeGtin.activeDateRange.startDate <> 'null' THEN date (skus1.gtins.activeGtin.activeDateRange.startDate) 
                    WHEN skus1.gtins.activeGtin.activeDateRange.endDate <> 'null' THEN date(skus1.gtins.activeGtin.activeDateRange.endDate) 
                    ELSE null 
                END AS effective_date  
        FROM product_temp LATERAL VIEW explode(skus) exploded_table AS skus1
        """). \
        withColumn('load_date', F.lit(load_date).cast('string')). \
        withColumn('source_file_path',F.lit(input_path).cast('string')). \
        withColumn('source_file_name',F.regexp_extract(F.input_file_name(),'([^/]+$)', 1).cast('string')) # saves the input file name


    existing_product_table = spark.table("{0}.{1}".format(product_db, product_table))
    # Losing data when overriding, so cache
    existing_product_table.cache()

    logging.info("This is the count for existing product table : " + str(existing_product_table.count()))

    existing_product_table.registerTempTable("existing_table")
    product_df.registerTempTable("product_table")

    unique_product = spark.sql("""
        SELECT a.* 
        FROM existing_table a LEFT OUTER JOIN product_table b ON a.uuid = b.uuid WHERE b.uuid IS null""")
    complete_product = unique_product.union(product_df).distinct()

    logging.info("This is the count for product after inserting/updating : " + str(complete_product.count()))

    return complete_product


if __name__ == '__main__':

    if(len(sys.argv)) != 2:
        raise Exception("Insufficient input arguments provided......")

    logging.info("Loading input Dictionary values into dictionary.........")
    input_dict = dict(json.loads(sys.argv[1]))

    file_path = str(input_dict.get('target_path'))
    product_db = str(input_dict.get('product_db'))
    product_table = str(input_dict.get('product_table'))
    load_date = str(input_dict.get('run_dt'))

    target_path = file_path + load_date + "/"

    logging.info("Instantiate Spark Session.........")
    sparkSession = get_spark_session("Parsing_Product")

    logging.info("starting the spark process for given product feed.......")

    process_start_time = time.time()

    product_df = process_product_feed(sparkSession, input_dict)

    logging.info("Refreshing target path " +target_path)

    refresh_cmd = 'aws s3 rm {0} --recursive'.format(target_path)
    subprocess.call(refresh_cmd, shell=True)


    logging.info("Saving files to target path " +target_path)

    product_df.write.format("parquet").mode("overwrite") \
        .option("compression", "snappy").save(target_path)

    process_end_time = time.time()

    logging.info("Time taken to process product feed: {0}".format(str(process_end_time - process_start_time)))


    logging.info("altering product table location to " + target_path)
    sparkSession.sql("alter table {0}.{1} set location '{2}'".format(product_db, product_table, target_path))


    logging.info("Terminating spark session.....")
    sparkSession.stop()

