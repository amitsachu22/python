# ==================================================================================
#
# load_product_by_geo.py
#
# If Boto3(aws component used in renaming files) is not installed in the cluster run this command:
#      "pip install --upgrade --user boto3"
#
# Workflow performs the following actions:
#
# 1. Loads new data from S3 (input)
# 2. Parses new data to desired format, calculates geo_part
# 3. Loads existing data from target hive table
# 4. Merge new data on top of existing
# 5. Overwrites the existing data (output)
#
# geo is assigned by marketplace.
#   GC where marketplace in Taiwan, China, Macao, Hong Kong
#
# Parameters:
#   Expects an input dictionary containing:
#       - app_name          : Application Name (optional)
#       - lpo_db            : LPO Database
#       - source_s3_path    : Source S3 path for new raw (json) product
#       - target_s3_path_base    : Target S3 path for product_by_geo table
#
# ==================================================================================
"""
History
=============================================================================================================
 Date           Author                  Desc
-------------------------------------------------------------------------------------------------------------
 06-26-2018     Vivek Reddy     New Script created

 05-16-2019     Dan Logan       Modified from product_daily_load.py to load_product_by_geo.py
                                    Implemented:
                                        - Move common filters in to target table
                                        - Add geo assignment from marketplace (currently only supports GC)
 06-05-2019     Dan Logan       Moved core functionality to method to be called externally in case of multiple sources.
============================================================================================================
Sample Command to run:
    spark-submit --master yarn --deploy-mode client --executor-memory 10G --driver-memory 12G \
        --executor-cores 2 --num-executors 18 --conf spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2 --files /etc/hive/conf/hive-site.xml, load_product_by_geo.py \
            '{ "lpo_db": "dev_dsm_lpo", "source_s3_path": "s3://ngap2-user-data/dstiengineering/lpo/dstiengineering/product/raw/date=2019-05-02/rawproductdelta-2019-05-02-1556763049277.json", "target_s3_path_base": "s3://nike-retail-managed/dev/lpo/product_by_geo/" }'
"""
import logging
import sys
import json
import time, datetime

from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, lit, when

try:
    import boto3
    import botocore
except ImportError as e:
    print("Not able to find boto libraires", e)
    sys.exit(1)

logging.basicConfig(level=logging.INFO)

PRODUCT_BY_GEO_TABLE = "product_by_geo"

# Should be migrated to common library
def create_spark_session(app_name):
    """
    :param app_name: Spark application name
    :return: returns new SparkSession
    """
    session_config = [("spark.serializer", "org.apache.spark.serializer.KryoSerializer"),
                      ("spark.shuffle.compress", "true"),
                      ("spark.scheduler.mode", "FAIR"),
                      ("spark.sql.shuffle.partitions", "200"),
                      ("spark.memory.fraction","0.7")]
    spark_conf = SparkConf().setAll(session_config) \
        .setAppName(app_name)
    spark_session = SparkSession.builder \
        .config(conf=spark_conf) \
        .enableHiveSupport() \
        .getOrCreate()
    spark_session.sparkContext.setLogLevel("WARN")
    return spark_session

def load_new_product_by_geo(spark_session, new_product_s3_path):
    logging.info("Fetching new product...")
    new_product = spark_session.read.json(new_product_s3_path) \
                .withColumn('sku', explode(col('skus'))) \
                .withColumn('marketplace', explode(col('marketplaces'))) \
                .withColumn('country', col('marketplace.marketplaceMeta.name')) \
                .withColumn('geo', when(col('country').isin('TAIWAN', 'CHINA', 'MACAO', 'HONG KONG'), 'GC')) \
                .select(col('id').alias('style_color_id'), \
                    col('sku.id').alias('sku_id'), \
                    col('geo'), \
                    col('vendorId').alias('vendor_id'), \
                    col('sku.gtins.activegtin.gtin').alias('gtin'), \
                    col('sku.gtins.activegtin.activedaterange.startdate').alias('active_start_date'), \
                    col('sku.gtins.activegtin.activedaterange.enddate').alias('active_end_date'), \
                    lit(str(datetime.datetime.now())).alias('last_modified') \
                ).filter(col('geo').isNotNull()) \
                .filter(col('gtin').isNotNull()) \
                .distinct()
    new_product.registerTempTable("new_product")
    return new_product

def load_existing_product_by_geo(spark_session, lpo_db):
    logging.info("Fetching existing product...")
    existing_product = spark_session.table("{db}.{table}".format(db=lpo_db, table=PRODUCT_BY_GEO_TABLE))
    existing_product.cache() # Required to overwrite the target table in save step
    existing_product.registerTempTable("existing_product")
    return existing_product

def minus_new_product_from_existing_product(spark_session):
    return spark_session.sql("SELECT e.* FROM existing_product e LEFT OUTER JOIN new_product n ON e.style_color_id = n.style_color_id WHERE n.style_color_id is null")

def union_existing_and_new_product(spark_session, new_product_s3_path, lpo_db):
    new_product = load_new_product_by_geo(spark_session, new_product_s3_path)
    load_existing_product_by_geo(spark_session, lpo_db)
    existing_products_to_maintain = minus_new_product_from_existing_product(spark_session)
    return existing_products_to_maintain.union(new_product).distinct()

def create_product_by_geo(spark_session, lpo_db, product_by_geo_s3_path):
    spark_session.sql("CREATE EXTERNAL TABLE IF NOT EXISTS {db}.{table} (style_color_id STRING, sku_id STRING, geo STRING, vendor_id STRING, gtin STRING, active_start_date STRING, active_end_date STRING, last_modified STRING) STORED AS PARQUET LOCATION '{s3_path}'".format(db=lpo_db, table=PRODUCT_BY_GEO_TABLE, s3_path=product_by_geo_s3_path))

def save_product_by_geo(spark_session, lpo_db, product_by_geo, product_by_geo_s3_path):
    logging.info("Saving updated product...")
    product_by_geo.write.format("parquet").mode("overwrite").option("compression", "snappy").save(product_by_geo_s3_path)
    spark_session.sql("ALTER TABLE {db}.{table} SET LOCATION '{s3_path}'".format(db=lpo_db, table=PRODUCT_BY_GEO_TABLE, s3_path=product_by_geo_s3_path))

def check_if_table_exists(spark_session, lpo_db):
    all_tables = spark_session.catalog.listTables(dbName=lpo_db)
    for table in all_tables:
        if table.name == PRODUCT_BY_GEO_TABLE:
            return True
    return False

def delete_from_s3(s3_location):
    bucket_and_key_path = parse_s3_scheme_url(s3_location)
    s3 = boto3.resource('s3')
    for key in s3.Bucket(name=bucket_and_key_path['bucket']).objects.filter(Prefix=bucket_and_key_path['key_path']):
        key.delete()

def getTableLocation(spark_session, lpo_db):
    return spark_session.sql('describe extended {db}.{table}'.format(db=lpo_db, table=PRODUCT_BY_GEO_TABLE)).filter(col('col_name') == 'Location').select(col('data_type')).take(1)[0].data_type

def getOrDefault(parameters, key, default):
    value = parameters.get(key)
    return value if value != None else default

def get(parameters, key):
    value = parameters.get(key)
    if value is None:
        raise Exception("Required parameter {key} was not provided".format(key=key))
    return value

def format_product_by_geo_s3_path(base, time_in_millis):
    return '{base}/latest={time_in_millis}/'.format(base=base, time_in_millis=time_in_millis)

def parse_s3_scheme_url(url):
    # TODO: check if format is s3://mybucket/my/key/path
    bucket_and_path = url[5:] # removes s3://
    index_of_first_forard_slash = bucket_and_path.index('/')
    bucket = bucket_and_path[:index_of_first_forard_slash]
    key_path = bucket_and_path[index_of_first_forard_slash + 1:]
    return dict(bucket=bucket, key_path=key_path)

def refresh_product_by_geo(spark_session, lpo_db, product_by_geo_s3_path_base, new_product_s3_path):
    if not check_if_table_exists(spark_session, lpo_db):
        logging.info("Table {table} did not exist...".format(table=PRODUCT_BY_GEO_TABLE))
        create_product_by_geo(spark_session, lpo_db, format_product_by_geo_s3_path(product_by_geo_s3_path_base, 0))
    existing_product_s3_path = getTableLocation(spark_session, lpo_db)
    product_by_geo = union_existing_and_new_product(spark_session, new_product_s3_path, lpo_db)
    save_product_by_geo(spark_session, lpo_db, product_by_geo, format_product_by_geo_s3_path(product_by_geo_s3_path_base, get_current_time_in_millis()))
    logging.info("Cleanup...")
    delete_from_s3(existing_product_s3_path)

def get_current_time_in_millis():
    return int(round(time.time()*1000))

if __name__ == '__main__':

    if(len(sys.argv)) != 2:
        raise Exception("Expecting single parameter, dictionary containing parameters")


    logging.info("Initiating...")

    parameters = dict(json.loads(sys.argv[1]))
    app_name = getOrDefault(parameters, 'app_name', 'load_product_by_geo')
    spark_session = create_spark_session(app_name)

    logging.info("Spark session initialized, process begin...")
    process_start_time = time.time()

    lpo_db = getOrDefault(parameters, 'lpo_db', 'dev_dsm_lpo')
    product_by_geo_s3_path_base = get(parameters, 'target_s3_path_base')

    new_product_s3_path = get(parameters, 'source_s3_path')

    refresh_product_by_geo(spark_session, lpo_db, product_by_geo_s3_path_base, new_product_s3_path)

    logging.info("Finished...")
    process_end_time = time.time()
    logging.info("Processing took {} seconds...".format(str(process_end_time - process_start_time)))

    spark_session.stop()
