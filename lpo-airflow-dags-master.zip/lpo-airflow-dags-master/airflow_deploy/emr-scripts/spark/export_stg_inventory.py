# ==================================================================================
#
# export_stg_inventory.py
#
# Given inclusive beginning or duration, fetch inventory and map gtin to product id, store code to location_id
# Merge partitions, gzip, assume role and push to remote S3
# Save to S3 by date and time
#
# If Boto3(aws component used in renaming files) is not installed in the cluster run this command:
#      "pip install --upgrade --user boto3"
#
# Workflow performs the following actions: [todo]
#
#
# Parameters:
#   Expects an input json object containing:
#       - app_name              : Application Name (optional)
#       - env_name              : Runtime environment name, one of sbx, non, prd
#       - inventory_load        : Inventory load property file name
#       - env_properties        : Environment properties file name
#
# ==================================================================================
"""
History
=============================================================================================================
 Date           Author                  Desc
-------------------------------------------------------------------------------------------------------------
 06-07-2019     Dan Logan       Initial workflow
============================================================================================================
"""
import sys, logging, time
import sys
import lpo_common_functions as l
import export2thecommons as e
import json
from pyspark.sql.functions import col, min, max, sum, lit
from pyspark.sql.types import StringType

### geo_part defaults to 'CHN', start_date defaults to '2015-06-01' ; if not provided
def fetchInventoryTable(spark_session, start_date='2015-06-01', region_code='CN'):
    return spark_session.table('dtc_integrated.dtc_bm_inventory_daily') \
                    .filter(col("region_cd") == region_code) \
                    .filter(col("inv_snapshot_dt") >= start_date) \
                    .filter(col("eop_unit_qty") >= 0) \
                    .select(col("eop_unit_qty").alias("CLOSING_INVENTORY_QTY"), col("inv_snapshot_dt").alias("start_dt"), col("str_id").alias("store_code"), col("gtin")) \
                    .withColumn("OPENING_INVENTORY_QTY", lit(None).cast(StringType()))

def fetchLocationTable(spark_session, lpo_db='dsm_lpo'):
    return spark_session.table("{db}.location_gc".format(db=lpo_db)) \
                        .select("location_id", col("location_name").alias("site_code")) \
                        .distinct();

def fetchProductTable(spark_session, regionCode="GC", lpo_db='dsm_lpo'):
    return spark_session.table("{db}.product_by_geo".format(db=lpo_db)) \
                        .filter(col("geo") == regionCode) \
                        .select(col("gtin"), col("sku_id")) \
                        .distinct()

def map_inventory_to_lpo_identifiers(spark_session, inventory, product, location):
    product.persist()
    location.persist()
    stg_inventory = inventory.join(product, [inventory["gtin"] == product["gtin"]], "inner") \
        .join(location, [inventory["store_code"] == location["site_code"]], "inner") \
        .select(col("sku_id").alias("product_id"), \
            col("location_id"), \
            col("start_dt"), \
            col("OPENING_INVENTORY_QTY"), \
            col("CLOSING_INVENTORY_QTY"))
    return stg_inventory

def get_start_date(parameters, config):
    """Calculating start date to be used for extract.
        Start is either 2015-06-01 for full load, or calculated from today based on a provided duration.
        Duration can be provided from parameters for from inventory_load properties.
    """
    if parameters.get("is_full_load") == True:
        return '2015-06-01'
    duration = parameters.get("duration")
    if duration is None:
        inventory_load_region_key = l.getOrDefault(parameters, "inventory_load_region_key", "default_region")
        duration = config.get(inventory_load_region_key, "process_days")
    return l.calculate_start_date(duration)

if __name__ == '__main__':

    if(len(sys.argv)) != 2:
        raise Exception("Expecting single parameter, dictionary containing parameters")

    logging.basicConfig(level=logging.INFO)
    logging.info("Initiating...")

    parameters = dict(json.loads(sys.argv[1]))

    config_file_keys = []
    config_file_keys.append(l.get(parameters, 'inventory_load'))
    config_file_keys.append(l.get(parameters, 'env_properties'))
    config = l.get_config(config_file_keys)

    env_name = l.getOrDefault(parameters, 'env_name', 'prd')

    if env_name not in ['sbx', 'non', 'prd']:
        raise Exception("env_name was not an expected value")

    app_name = l.getOrDefault(parameters, 'app_name', 'export_stg_inventory')
    spark_session = l.create_spark_session(app_name)

    logging.info("Spark session initialized, process begin...")
    process_start_time = time.time()

    start_date = get_start_date(parameters, config)
    lpo_db = config.get(env_name, "lpo_db")

    inventory = fetchInventoryTable(spark_session, start_date)
    location = fetchLocationTable(spark_session=spark_session)
    product = fetchProductTable(spark_session=spark_session, regionCode="GC", lpo_db=lpo_db)
    mapped_inventory_all = map_inventory_to_lpo_identifiers(spark_session, inventory, product, location)

    header = l.getOrDefault(parameters, "header_row", "product_id|location_id|start_dt|opening_inventory_qty|closing_inventory_qty\n")
    temp_base_path = config.get(env_name, "temp_base_path")
    target_base_path = config.get(env_name, "target_base_path")
    filename_base = "stg_inventory_fact"
    assume_role_arn = config.get(env_name, "assume_role_arn")
    current_iso_date = l.calculate_current_iso_date()
    current_time_in_millis = l.get_current_time_in_millis()
    allow_gzip = l.getOrDefault(parameters, "allow_gzip", False)

    e.export(
        source_df = mapped_inventory_all,
        header = header,
        temp_base_path = temp_base_path,
        target_base_path = target_base_path,
        filename_base = filename_base,
        role_arn = assume_role_arn,
        date_part = current_iso_date,
        time_in_millis = current_time_in_millis,
        allow_gzip = allow_gzip
    )

    logging.info("Finished...")
    process_end_time = time.time()
    logging.info("Processing took {} seconds...".format(str(process_end_time - process_start_time)))

    spark_session.stop()
