# ==================================================================================
#
# load_product_geo_sqs_driver.py
#
# Given an sqs queue which receives s3 events for new raw product files; For each, run load_product_by_geo to refresh the product_by_geo table.
#
# Parameters:
#   Expects an input json object containing:
#       - app_name              : Application Name (optional)
#       - env_name              : Runtime environment name, one of sbx, non, prd
#       - product_by_geo_env    : File name for properties file product_by_geo_env
#       - target_s3_path_base   : Target S3 path for product_by_geo table
#
# Environment variables:
#   product_by_geo_env:
#       Sections:
#       - environment names sbx, non, prd
#       Properties:
#       - raw_product_queue_name        : SQS Queue Name
#       - raw_product_queue_account     : Account Number where the queue exists
#       - raw_product_queue_region      : AWS region where the queue exists
#       - product_by_geo_s3_path_base   : Path for product_by_geo hive table
#
# ==================================================================================
import logging
import sys
import json
import load_product_by_geo
import lpo_common_functions as lpo_common
import time

try:
    import boto3
    import botocore
except ImportError as e:
    print("Not able to find boto libraires", e)
    sys.exit(1)

if __name__ == '__main__':
    if(len(sys.argv)) != 2:
        raise Exception("Expecting single parameter, dictionary containing parameters")

    logging.basicConfig(level=logging.INFO)
    logging.info("Initiating...")

    parameters = dict(json.loads(sys.argv[1]))

    config_file_keys = []
    config_file_keys.append(lpo_common.get(parameters, 'product_by_geo_env'))
    config_file_keys.append(lpo_common.get(parameters, 'splunk_properties'))
    config = lpo_common.get_config(config_file_keys)

    env_name = lpo_common.getOrDefault(parameters, 'env_name', 'prd')

    if env_name not in ['sbx', 'non', 'prd']:
        raise Exception("env_name was not an expected value")

    app_name = lpo_common.getOrDefault(parameters, 'app_name', 'refresh_product_by_geo')

    splunk_handler = lpo_common.get_splunk_handler(config, env_name, app_name)
    logging.getLogger('').addHandler(splunk_handler)

    spark_session = lpo_common.create_spark_session(app_name)

    logging.info("Beginning to fetch messages from the queue...")

    queue_name = config.get(env_name, 'raw_product_queue_name')
    queue_account = config.get(env_name, 'raw_product_queue_account')
    queue_region = config.get(env_name, 'raw_product_queue_region')

    sqs = boto3.resource('sqs', region_name=queue_region)
    queue = sqs.get_queue_by_name(QueueName=queue_name, QueueOwnerAWSAccountId=queue_account)

    lpo_db = config.get(env_name, 'lpo_db')
    product_by_geo_s3_path_base = config.get(env_name, 'product_by_geo_s3_path_base')

    process_start_time = time.time()
    while True:
        messages = queue.receive_messages()
        if len(messages) == 0:
            logging.info("Finished processing messages...")
            break
        for message in messages:
            sns_message = dict(json.loads(message.body))
            if 'Amazon S3 Notification' in sns_message.get('Subject'):
                s3_event = json.loads(sns_message.get('Message'))
                if 'Event' not in s3_event or 's3:TestEvent' not in s3_event.get('Event'):
                    s3_record = s3_event.get('Records')[0].get('s3')
                    bucket_name = s3_record.get('bucket').get('name')
                    key_path = s3_record.get('object').get('key').replace('%3D','=')
                    new_product_s3_path = 's3://{bucket_name}/{key_path}'.format(bucket_name=bucket_name, key_path=key_path)
                    try:
                        logging.info("Refreshing table with {} ...".format(new_product_s3_path))
                        load_product_by_geo.refresh_product_by_geo(spark_session, lpo_db, product_by_geo_s3_path_base, new_product_s3_path)
                    except:
                        logging.error("Failed to refresh product by geo for {}".format(new_product_s3_path))
                        raise
            message.delete()
    process_end_time = time.time()
    logging.info("Processing took {} seconds...".format(str(process_end_time - process_start_time)))
    spark_session.stop()
