# ==================================================================================
#
# FileName: lpo_archive_service.py
#
# Description: this script performs the following tasks
# 1. Identifies the staging files from stage hive table
# 2. archives the identified files from source to destination buckets.
#
# Parameters Required:
#               1. stg_hive_db
#               2. stg_hive_table
#               3. s3_archive_path

# ==================================================================================
"""
History
=============================================================================================================
 Date              Author                  Desc
-------------------------------------------------------------------------------------------------------------
 07-16-2018     Naveen Raj Kurapati     New Script created
============================================================================================================
Sample Command To RUN:

spark-submit \
      --jars s3://nike-emr-working/prod/udfs/hive/hive-contrib.jar \
      --master yarn \
      --files /etc/hive/conf/hive-site.xml, lpo_archive_service.py '{"s3_archive_path":"s3://nike-retail-managed/qa/archive/rawdata/lpo/location/gc/","stg_hive_db":"QA_STG_lpo","stg_hive_table":"location_gc"}'

"""

import logging
import json
import sys
import subprocess
from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import *


#Intialize logging
logging.basicConfig(level=logging.INFO)

sparkProps = [("spark.shuffle.compress", "true"), ("spark.scheduler.mode", "FAIR"), ("spark.speculation", "false")]

sparkConfig = SparkConf().setAll(sparkProps)

spark = SparkSession.builder.appName("WFM_Archive_Service") \
    .config(conf=sparkConfig) \
    .enableHiveSupport() \
    .getOrCreate()


def get_hive_sourcefiles(hive_db, hive_table):
    source_table = spark.table("{0}.{1}".format(hive_db, hive_table))
    input_files = source_table.select(input_file_name().alias("input_file_name")).distinct().persist()
    logging.info("Total input files is: {}".format(input_files.select("input_file_name").count()))
    files_list = input_files.rdd.flatMap(lambda x: x) \
        .map(lambda x: str(x)).collect()
    spark.catalog.clearCache()
    return files_list


def archive_files(archive_path, hive_db, hive_table):
    source_files = get_hive_sourcefiles(hive_db,hive_table)
    for f in source_files:
        archive_cmd = 'aws s3 mv {0} {1}'.format(f, archive_path)
        subprocess.call(archive_cmd, shell=True)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise Exception("Insufficient input arguments provided")

    input_dict = dict(json.loads(sys.argv[1]))

    stg_hive_db = input_dict.get('stg_hive_db')
    stg_hive_table = input_dict.get('stg_hive_table')
    s3_archive_path = input_dict.get('s3_archive_path')

    logging.info("   s3_archive_path       : " + s3_archive_path)
    logging.info("   stg_hive_db           : " + stg_hive_db)
    logging.info("   stg_hive_table        : " + stg_hive_table)

    logging.info("Started Archive process between source and destination buckets.....")
    archive_files(s3_archive_path, stg_hive_db, stg_hive_table)
    logging.info("Completed Archival task successfully.......")

    logging.info("Terminating spark session...")
    spark.stop()


