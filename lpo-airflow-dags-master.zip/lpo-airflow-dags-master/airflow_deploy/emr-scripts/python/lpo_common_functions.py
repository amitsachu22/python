import ConfigParser
import datetime, time
from pyspark import SparkConf
from pyspark.sql import SparkSession
from splunk_handler import SplunkHandler

def create_spark_session(app_name):
    """"Create a new spark session

    Keyword arguments:
    app_name    -- Spark application name
    """
    session_config = [("spark.shuffle.compress", "true"),\
                           ("spark.scheduler.mode", "FAIR"),\
                           ("spark.sql.shuffle.partitions", "200"),\
                           ("spark.driver.maxResultSize", "0"),\
                           ("spark.sql.autoBroadcastJoinThreshold", "-1")]
    spark_conf = SparkConf().setAll(session_config).setAppName(app_name)
    spark_session = SparkSession.builder.config(conf=spark_conf).enableHiveSupport().getOrCreate()
    spark_session.sparkContext.setLogLevel("WARN")
    return spark_session

def get_current_time_in_millis():
    """Calculate current time in milliseconds"""
    return int(round(time.time()*1000))

def calculate_current_iso_date():
    """Calculates current date utc in iso format YYYY-MM-DD"""
    return datetime.datetime.utcnow().date().isoformat()

def get(parameters, key):
    """Retrieve a required parameter by key

    Keyword arguments:
    parameters  -- a dictionary of parameters
    key         -- the key to fetch from dictionary
    """
    value = parameters.get(key)
    if value is None:
        raise Exception("Required parameter {key} was not provided".format(key=key))
    return value

def getOrDefault(parameters, key, default):
    """Retrieve a required parameter by key, return default otherwise

    Keyword arguments:
    parameters  -- a dictionary of parameters
    key         -- the key to fetch from dictionary
    default     -- the default to fallback to
    """
    value = parameters.get(key)
    return value if value != None else default

def calculate_start_date(duration):
    """Given a duration, calculate start date given today as end date

    Keyword arguments:
    duration    -- Number of days to calculate backward
    """
    return (datetime.datetime.utcnow() - datetime.timedelta(int(duration))).date().isoformat()

def get_config(config_file_keys):
    '''Given file names parse the config files and return ConfigParser

    Keyword arguments:
    config_file_keys    --  A list of strings of files to parse properties from
    '''
    config = ConfigParser.ConfigParser()
    config.read(config_file_keys)
    return config

def get_splunk_handler(config, env_name, source_suffix):
    splunk_config_env_section_name = "splunk_{}".format(env_name)
    host = config.get("splunk_common", "host")
    port = config.get("splunk_common", "port")
    sourcetype = config.get("splunk_common", "sourcetype")
    hostname = config.get("splunk_common", "hostname")
    source_prefix = config.get("splunk_common", "source_prefix")
    token = config.get(splunk_config_env_section_name, "token")
    index = config.get(splunk_config_env_section_name, "index")
    source = "{}-{}".format(source_prefix, source_suffix)
    return SplunkHandler(
        host=host,
        port=port,
        token=token,
        source=source,
        hostname=hostname,
        sourcetype=sourcetype,
        index=index
    )
