# ==================================================================================
#
# utilities.py
#
# This script provides handy utility functions for developer ease to reuse the
# code modules and avoid code duplication across application
# 1. Method get_s3file_identifiers : returns the identifiers list to point to the objects in s3 file system.
# 2. Method copy_files_to_s3target: renames the files using file prefix and copies files to target bucket
# ==================================================================================
"""
History
=============================================================================================================
 Date           Author                  Desc
-------------------------------------------------------------------------------------------------------------
 05-11-2018    Naveen Raj Kurapati     New Script created.
============================================================================================================

"""

import smtplib
import sys
import subprocess
import logging
import datetime
import os
from os.path import expanduser
import shutil

try:
    import boto3
    import botocore
except ImportError as e:
    print("Not able to find boto libraires", e)
    sys.exit(1)

logging.basicConfig(level=logging.INFO)

s3_resource = boto3.resource('s3')
s3_client_resource = boto3.client('s3')
sts_client = boto3.client('sts')


def get_s3file_identifiers(s3path):
    """
    :param s3path: input s3 file path as string
    :return: list of s3 file identifiers
    """
    bucket = s3path.split('/')[2]
    prefix = s3path.split('{0}'.format(bucket), 1)[1].replace('/', '', 1)
    return [bucket, prefix]


def copy_files_to_s3target(src_path, target_path, tgt_file_prefix, input_file_format, output_file_format="txt"):
    """
    :param src_path: source s3 path
    :param target_path: target s3 path
    :param tgt_file_prefix: file prefix required to generate the output filename
    :param input_file_format: source file format to check the files
    :param output_file_format: Target file format to save the file
    :return: void method
    """
    src_bucket_name = get_s3file_identifiers(src_path)[0]
    src_prefix = get_s3file_identifiers(src_path)[1]

    tgt_bucket_name = get_s3file_identifiers(target_path)[0]
    tgt_prefix = get_s3file_identifiers(target_path)[1]

    logging.info("Source bucket: {0} and Prefix: {1}".format(src_bucket_name, src_prefix))
    logging.info("Target bucket: {0} and Prefix: {1}".format(tgt_bucket_name, tgt_prefix))

    dest_path = tgt_prefix + tgt_file_prefix + "_"
    tgt_bucket = s3_resource.Bucket(tgt_bucket_name)

    bucket = s3_resource.Bucket(name=src_bucket_name)
    s3_file_obj = bucket.objects.filter(Prefix=src_prefix)

    src_file_list = []
    for obj in s3_file_obj:
        input_file = str(obj.key).split('/')[-1]
        if "."+str(input_file_format).lower() in input_file:
            src_file_list.append(input_file)

    count = 0
    for f in src_file_list:
        copy_source = {
            'Bucket': src_bucket_name,
            'Key': src_prefix + f
        }
        tgt_bucket.copy(copy_source, dest_path + str(count) + "." + str(output_file_format).lower())
        count += 1

def get_assumed_role_resource(input_arn, session_duration=1):
    """

    :param input_arn: Input ARN for target aws account to assume role
    :param session_duration: required duration in hours.
    :return: assumed s3 resource.
    """
    session_date = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%S')
    assumed_role_object = sts_client.assume_role(
        RoleArn=input_arn,
        RoleSessionName="DF_Assumed_role_session_" + str(session_date),
        DurationSeconds=(3600 * int(session_duration)),
    )
    credentials = assumed_role_object['Credentials']
    s3_assumed_resource = boto3.resource(
        's3',
        aws_access_key_id=credentials['AccessKeyId'],
        aws_secret_access_key=credentials['SecretAccessKey'],
        aws_session_token=credentials['SessionToken'],
    )
    return s3_assumed_resource


# arn = arn:aws:iam::069272765570:role/dsmgplpo7d58b2d6-data-foundation-role
def cross_account_file_copy(src_path, target_path, src_file_prefix, input_role_arn, feed_name="cross_acc_temp"):
    """
    :param src_path: source s3 path
    :param target_path: target s3 path
    :param src_file_prefix: file prefix required to identify the files to transfer
    :param input_role_arn: Arn details of target aws account to assume role
    :param feed_name: temporary file prefix to be created in local node to transfer files
    :return: void method
    """
    src_bucket_name = get_s3file_identifiers(src_path)[0]
    src_prefix = get_s3file_identifiers(src_path)[1]
    tgt_bucket_name = get_s3file_identifiers(target_path)[0]

    tgt_prefix = get_s3file_identifiers(target_path)[1]
    logging.info("Source bucket: {0} and Prefix: {1}".format(src_bucket_name, src_prefix))
    logging.info("Target bucket: {0} and Prefix: {1}".format(tgt_bucket_name, tgt_prefix))

    assumed_role = get_assumed_role_resource(str(input_role_arn))
    src_bucket = s3_resource.Bucket(src_bucket_name)
    tgt_bucket = assumed_role.Bucket(tgt_bucket_name)

    # home_dir = expanduser("~/")
    # current_dir = home_dir+feed_name
    # if not os.path.exists(current_dir):
    #     os.makedirs(current_dir)
    # local_dir = current_dir + '/'

    bucket = s3_resource.Bucket(name=src_bucket_name)
    s3_file_obj = bucket.objects.filter(Prefix=src_prefix)
    logging.info("started downloading files to local storage from s3.......")

    src_file_list = []
    for obj in s3_file_obj:
        key = obj.key
        input_file = str(key).split('/')[-1]
        if src_file_prefix in input_file:
            logging.info("downloading file with key:{0} and to local_path:{1}".format(key, input_file))
            # src_bucket.download_file(key, local_dir+input_file)
            src_bucket.download_file(key, input_file)
            src_file_list.append(input_file)

    logging.info("started uploading files into target bucket from storage.............")
    for f in src_file_list:
        tgt_bucket.upload_file(f, tgt_prefix+f)

    logging.info("Removing the temporary folder with the downloaded files.....")
    # try:
    #     shutil.rmtree(local_dir)
    # except OSError as e:
    #     print("Error: {0} - {1}.".format(e.filename, e.strerror))

