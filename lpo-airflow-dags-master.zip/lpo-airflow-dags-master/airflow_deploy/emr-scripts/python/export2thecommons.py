import logging
from lpo_common_functions import get_current_time_in_millis
import boto3
import gzip
import os
import shutil
import time

def assume_role(role_arn):
    sts_client = boto3.client('sts')
    assumed_role = sts_client.assume_role(
        RoleArn = role_arn,
        RoleSessionName = "export_{time_in_millis}".format(time_in_millis = get_current_time_in_millis())
    )
    return assumed_role['Credentials']

def create_s3_resource(role_arn = None):
    if role_arn is None:
        return boto3.resource('s3')
    else:
        credentials = assume_role(role_arn)
        return boto3.resource(
            's3',
            aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken']
        )

def parse_s3_scheme_url(url):
    # TODO: check if format is s3://mybucket/my/key/path
    bucket_and_path = url[5:] # removes s3://
    index_of_first_forard_slash = bucket_and_path.index('/')
    bucket = bucket_and_path[:index_of_first_forard_slash]
    key_path = bucket_and_path[index_of_first_forard_slash + 1:]
    return dict(bucket=bucket, key_path=key_path)

def delete_from_s3(s3_location):
    bucket_and_key_path = parse_s3_scheme_url(s3_location)
    s3 = boto3.resource('s3')
    for key in s3.Bucket(name=bucket_and_key_path['bucket']).objects.filter(Prefix=bucket_and_key_path['key_path']):
        key.delete()

def write_header(local_path, header, allow_gzip):
    if allow_gzip:
        with gzip.open(local_path, 'wb') as f:
            f.write(header.encode("utf-8"))
    else:
        with open(local_path, 'w') as f:
            f.write(header.encode("utf-8"))


def remove_hanging_slash_from_str(value):
    return value[:len(value)-1] if value.endswith("/") else value

##
## Given a data frame
## Save parts to S3, each partition can do this independently
## Fetch parts, write header to target, merge parts to target
## Upload merged file to target directory
## Cleanup
##
def export(source_df, header, temp_base_path, target_base_path, filename_base, role_arn, date_part, time_in_millis, allow_gzip=False):
    temp_base_path =  remove_hanging_slash_from_str(temp_base_path)
    target_base_path =  remove_hanging_slash_from_str(target_base_path)
    temp_path = "{base_path}/date={date}/timestamp={time_in_millis}".format(base_path=temp_base_path, date=date_part, time_in_millis=time_in_millis)
    logging.info("Writing data frame to {} ...".format(temp_path))
    # write to s3
    source_df.write.csv(temp_path, mode="overwrite", compression=("gzip" if allow_gzip else None), sep='|')
    logging.info("Successfully wrote dateframe to s3 ...")
    # fetch all parts locally
    bucket_and_key_path = parse_s3_scheme_url(temp_path)
    local_dir = "{}_parts".format(filename_base)
    os.mkdir(local_dir)
    try:
        bucket = create_s3_resource().Bucket(name=bucket_and_key_path['bucket'])
        logging.info("Fetching parts from s3://{}/{}".format(bucket_and_key_path['bucket'], bucket_and_key_path['key_path']))
        for object in bucket.objects.filter(Prefix=bucket_and_key_path['key_path']):
            attempts = 0
            max_attempts = 5
            # Attempt up to max_attempts to download the file, with linear backoff between attempts
            while attempts < max_attempts:
                try:
                    file_name_part = str(object.key).split('/')[-1]
                    bucket.download_file(object.key, "{dir}/{filename}".format(dir=local_dir, filename=file_name_part))
                    break
                except:
                    attempts += 1
                    logging.warn("attempt {} failed to download part {} ...".format(str(attempts), object.key))
                    if attempts >= max_attempts:
                        raise
                    time.sleep(5*attempts)
        # merge parts in to single file
        file_extension = "txt.gz" if allow_gzip else "txt"
        local_filename = '{filename_base}_{date}_{time_in_millis}.{ext}'.format(filename_base=filename_base,date=date_part.replace("-",""), time_in_millis=time_in_millis, ext=file_extension)
        try:
            logging.info("Writing header ...")
            write_header(local_filename, header, allow_gzip)
            logging.info("Merging parts ...")
            with open(local_filename, 'ab') as target_file:
                for fn in os.listdir(local_dir):
                    with open("{}/{}".format(local_dir, fn), 'rb') as source_file:
                        shutil.copyfileobj(source_file, target_file)
            # copy merged file to s3
            target_path = '{base_path}/date={date}/time={time_in_millis}/{filename}'.format(base_path=target_base_path, date=date_part, time_in_millis=time_in_millis, filename=local_filename)
            logging.info("Uploading result to {} ...".format(target_path))
            bucket_and_key_path = parse_s3_scheme_url(target_path)
            create_s3_resource(role_arn).Bucket(name=bucket_and_key_path['bucket']).upload_file(
                Filename=local_filename,
                Key=bucket_and_key_path['key_path']
            )
            logging.info("Cleaning up S3 ...")
            delete_from_s3(temp_path)
        finally:
            logging.info("Cleaning up temp file ...")
            if os.path.exists(local_filename):
               os.remove(local_filename)
    finally:
        logging.info("Cleaning up merge files ...")
        if os.path.exists(local_dir):
           shutil.rmtree(local_dir)
