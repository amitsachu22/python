# ==================================================================================
#
# FileName: wfm_staging_service.py
#
# Description: this script performs the following tasks
# 1. Identifies the _success files in the landing folder
# 2. copies the corrsponding files with success into the AWS s3 stage path
#
# Parameters required:
#               1. s3_src_path
#               2. s3_dest_path
#               3. search_pattern
#               4. run_date
# ==================================================================================
"""
History
=============================================================================================================
 Date              Author                  Desc
-------------------------------------------------------------------------------------------------------------
 03-21-2018     Naveen Raj Kurapati     New Script created
============================================================================================================
Sample Command To RUN:

spark-submit --master yarn \
      --files /etc/hive/conf/hive-site.xml, lpo_staging_service.py '{"src_path": "s3://dsmdemand117f359-sbx-us-east-1/data/application/location/snapshots/GC/2018-07-02/", "dest_path":"s3://nike-retail-stage/dev/nkurap/lpo/location/","search_pattern":"stg-location-20"}'

"""

import logging
import sys
from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import subprocess
import json

try:
    import boto3
    import botocore
except ImportError as e:
    print("Not able to find boto libraires", e)
    sys.exit(1)

# Initialize logging
logging.basicConfig(level=logging.INFO)

# Initialize SparkSession
sparkProps = [("spark.shuffle.compress", "true"), ("spark.scheduler.mode", "FAIR"), ("spark.speculation", "false")]

sparkConfig = SparkConf().setAll(sparkProps)

spark = SparkSession.builder.appName("WFM_Staging_Service") \
    .config(conf=sparkConfig) \
    .enableHiveSupport() \
    .getOrCreate()


def get_s3file_identifiers(s3path):
    """
    :param s3path: input s3 file path as string
    :return: list of s3 file identifiers
    """
    bucket = s3path.split('/')[2]
    prefix = s3path.split('{0}'.format(bucket), 1)[1].replace('/', '', 1)
    return [bucket, prefix]


def copy_files(s3_src_path, s3_target_path, s3_resource, search_format=''):
    src_bucket_name = get_s3file_identifiers(s3_src_path)[0]
    src_prefix = get_s3file_identifiers(s3_src_path)[1]
    tgt_bucket_name = get_s3file_identifiers(s3_target_path)[0]
    dest_path = get_s3file_identifiers(s3_target_path)[1]
    tgt_bucket = s3_resource.Bucket(tgt_bucket_name)

    logging.info("Source bucket: {0} and Prefix: {1}".format(src_bucket_name, src_prefix))

    src_bucket = s3_resource.Bucket(name=src_bucket_name)
    src_file_objs = src_bucket.objects.filter(Prefix=src_prefix)

    src_file_list = []
    for obj in src_file_objs:
        input_file = str(obj.key).split('/')[-1]
        if search_format != '':
            if str(search_format).lower() in str(input_file).lower():
                src_file_list.append(input_file)
        else:
            src_file_list.append(input_file)

    # Delete current files before appending to the stage.
    del_cmd = 'aws s3 rm {0}/ --recursive'.format(target_path)
    subprocess.call(del_cmd, shell=True)

    for f in src_file_list:
        copy_source = {
            'Bucket': src_bucket_name,
            'Key': src_prefix + f
        }
        logging.info("file being copied is : {0} ................".format(src_prefix + f))
        tgt_bucket.copy(copy_source, dest_path + f)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise Exception("Insufficient input arguments provided")

    input_dict = dict(json.loads(sys.argv[1]))

    logging.info("loading input arguments from Json key value pairs....")
    src_path = input_dict.get('src_path')
    target_path = input_dict.get('dest_path')
    search_pattern = input_dict.get('search_pattern')
    service = input_dict.get('service')

    logging.info("Number of input Arguments Passed: {0}".format(len(sys.argv)))
    logging.info("Arguments passed: {0}".format(str(sys.argv)))

    logging.info("   src_path            : " + src_path)
    logging.info("   dest_path           : " + target_path)
    logging.info("   search_pattern      : " + search_pattern)

    s3 = boto3.resource('s3')
    client = boto3.client('s3')

    try:
        logging.info("Started the file copy process between source and destination buckets.....")
        copy_files(src_path, target_path, s3, search_pattern)
        logging.info("Completed files copy task successfully.......")
    except Exception as e:
        print("Got exception while transferring files with message: {0}".format(str(e)))
        logging.info("Exiting due to exception in copy process.....")
        sys.exit(1)
    finally:
        logging.info("Terminating Spark Session.....")
        spark.stop()
